const C = require("./common");
const {
  Document, Packer, Paragraph, TextRun, HeadingLevel, Table, TableRow, TableCell,
  WidthType, ShadingType, BorderStyle, AlignmentType, PageBreak, Header, Footer,
  PageNumber, NumberOfPages, convertInchesToTwip, VerticalAlign, ExternalHyperlink, TableOfContents,
} = C;
const { P, Runs, H1, H2, bullet, caption, figure, table, img, NAVY, TEAL, GOLD, RED, GREEN, INK, MUT, LINE, SOFT } = C;

// ---------------- real numbers, read once ----------------
const fsn = require("fs");
const M = JSON.parse(fsn.readFileSync(require("path").join(__dirname, "..", "..", "outputs", "run_metrics.json")));
const H = JSON.parse(fsn.readFileSync(require("path").join(__dirname, "..", "..", "outputs", "run_history.json")));
const T = JSON.parse(fsn.readFileSync(require("path").join(__dirname, "..", "..", "outputs", "test_results.json")));
const R = M.reconciliation;
const fullRuns = H.filter(h => h.mode === "full");
const incRuns = H.filter(h => h.mode === "incremental");
const passN = T.filter(t => t.status === "PASS").length;

// ---------------- cover page ----------------
const NAME = "[Student full name]", ROLL = "[Roll number]", BATCH = "Databricks & Snowflake 2026",
      TRAINER = "[Trainer / faculty name]", DATE = "[DD Month 2026]", GH = "[github-username]";

function coverPage() {
  return [
    new Paragraph({ spacing: { after: 0 }, children: [] }),
    new Table({
      width: { size: 9350, type: WidthType.DXA }, columnWidths: [9350],
      borders: { top: { style: BorderStyle.NONE }, bottom: { style: BorderStyle.NONE }, left: { style: BorderStyle.NONE }, right: { style: BorderStyle.NONE }, insideHorizontal: { style: BorderStyle.NONE }, insideVertical: { style: BorderStyle.NONE } },
      rows: [new TableRow({ children: [new TableCell({
        width: { size: 9350, type: WidthType.DXA }, shading: { fill: NAVY, type: ShadingType.CLEAR },
        margins: { top: 500, bottom: 500, left: 400, right: 400 },
        children: [
          new Paragraph({ spacing: { after: 60 }, children: [new TextRun({ text: "DATABRICKS AND SNOWFLAKE  |  CAPSTONE PROJECT 2026", color: "FFFFFF", size: 19, bold: true, font: "Calibri" })] }),
          new Paragraph({ spacing: { before: 160, after: 160 }, children: [new TextRun({ text: "Customer Data Analytics using Snowflake and Databricks", color: "FFFFFF", size: 40, bold: true, font: "Calibri" })] }),
          new Paragraph({ children: [new TextRun({ text: "A medallion-architecture pipeline that cleans and analyses synthetic e-commerce sales data with PySpark on Databricks and serves it through Snowflake", color: "E8F1F8", size: 22, font: "Calibri" })] }),
        ],
      })] })],
    }),
    new Paragraph({ spacing: { before: 500 }, children: [] }),
    metaTable([["NAME", NAME], ["ROLL NUMBER", ROLL], ["BATCH", BATCH], ["SUBMITTED TO", TRAINER], ["DATE", DATE], ["GITHUB", GH]]),
    new Paragraph({ spacing: { before: 900 }, children: [] }),
    new Table({
      width: { size: 9350, type: WidthType.DXA }, columnWidths: [9350],
      borders: { top: { style: BorderStyle.SINGLE, size: 4, color: GOLD }, bottom: { style: BorderStyle.SINGLE, size: 4, color: GOLD }, left: { style: BorderStyle.SINGLE, size: 4, color: GOLD }, right: { style: BorderStyle.SINGLE, size: 4, color: GOLD }, insideHorizontal: { style: BorderStyle.NONE }, insideVertical: { style: BorderStyle.NONE } },
      rows: [new TableRow({ children: [new TableCell({
        width: { size: 9350, type: WidthType.DXA }, shading: { fill: "FFF7E6", type: ShadingType.CLEAR }, margins: { top: 180, bottom: 180, left: 240, right: 240 },
        children: [new Paragraph({ children: [
          new TextRun({ text: "BEFORE YOU SUBMIT  ", bold: true, size: 19, color: "6b4b00", font: "Calibri" }),
          new TextRun({ text: "Replace the bracketed cover-page fields above with your own name, roll number, trainer and date, and replace the GitHub username in Section 14 and the README. Every number in this report was produced by the code in this repository and is not a placeholder.", size: 19, color: "3b2b00", font: "Calibri" }),
        ] })],
      })] })],
    }),
    new Paragraph({ children: [new PageBreak()] }),
  ];
}
function metaTable(rows) {
  return new Table({
    width: { size: 9350, type: WidthType.DXA }, columnWidths: [2400, 6950],
    borders: { top: { style: BorderStyle.NONE }, bottom: { style: BorderStyle.NONE }, left: { style: BorderStyle.NONE }, right: { style: BorderStyle.NONE }, insideHorizontal: { style: BorderStyle.SINGLE, size: 2, color: LINE }, insideVertical: { style: BorderStyle.NONE } },
    rows: rows.map(([k, v]) => new TableRow({ children: [
      new TableCell({ width: { size: 2400, type: WidthType.DXA }, margins: { top: 110, bottom: 110 }, children: [new Paragraph({ children: [new TextRun({ text: k, bold: true, color: NAVY, size: 20, font: "Calibri" })] })] }),
      new TableCell({ width: { size: 6950, type: WidthType.DXA }, margins: { top: 110, bottom: 110 }, children: [new Paragraph({ children: [new TextRun({ text: v, size: 20, color: INK, font: "Calibri", italics: v.startsWith("[") })] })] }),
    ] })),
  });
}

// ---------------- TOC and list of figures ----------------
const TOC_ITEMS = [
  ["1. Problem Statement", ""], ["2. Objectives and Scope", ""], ["3. Solution and Features", ""],
  ["4. Tech Stack", ""], ["5. Data Architecture and Layer Design", ""], ["6. System Architecture", ""],
  ["7. Implementation Highlights", ""], ["8. Testing", ""], ["9. Data Quality and Performance Results", ""],
  ["10. Screenshots and Visual Results", ""], ["11. Challenges and Fixes", ""], ["12. Future Improvements", ""],
  ["13. Conclusion", ""], ["14. References and Links", ""], ["Submission Checklist", ""],
];
function tocPage() {
  return [
    H1("Table of Contents"),
    ...TOC_ITEMS.map(([t]) => new Paragraph({
      spacing: { after: 140 },
      tabStops: [{ type: "right", position: convertInchesToTwip(6.5), leader: "dot" }],
      children: [new TextRun({ text: t, size: 22, color: INK, font: "Calibri" })],
    })),
    new Paragraph({ children: [new PageBreak()] }),
  ];
}
const FIGS = [
  ["6.1", "Architecture diagram: source to Databricks Bronze/Silver/Gold to Snowflake to dashboards"],
  ["6.2", "ER / table relationship diagram for Silver and Gold"],
  ["6.3", "Pipeline flow with five quality checkpoints"],
  ["9.1", "Row counts per layer, local run (terminal output)"],
  ["9.2", "Data quality rule results, full load (terminal output)"],
  ["9.3", "Revenue reconciliation waterfall, local run (terminal output)"],
  ["9.4", "Run history across five executions (terminal output)"],
  ["9.5", "Stage timings across five executions (terminal output)"],
  ["9.6", "Test suite results, 16 of 16 passed (terminal output)"],
  ["10.1", "Monthly revenue trend"],
  ["10.2", "Top 10 categories by revenue"],
  ["10.3", "Delivery delay by state"],
  ["10.4", "Customer segments (RFM)"],
  ["10.5", "Order status mix"],
  ["10.6", "Payment types by value and installments"],
  ["10.7", "Quarantined rows by table and reason"],
  ["10.8", "Streamlit dashboard, running against the Gold CSV files"],
  ["10.9", "Static HTML dashboard, the version published as the live link"],
  ["10.10-10.15", "Cloud screenshots (Databricks jobs, Snowsight, Stream/Task) — to be captured, see screenshots/CAPTURE_GUIDE.md"],
];
function lofPage() {
  return [
    H1("List of Figures"),
    ...FIGS.map(([n, t]) => new Paragraph({
      spacing: { after: 90 },
      children: [new TextRun({ text: `Figure ${n}   `, bold: true, color: NAVY, size: 20, font: "Calibri" }), new TextRun({ text: t, size: 20, color: INK, font: "Calibri" })],
    })),
    new Paragraph({ children: [new PageBreak()] }),
  ];
}

// ---------------- section builders ----------------
function sec1() {
  return [
    H1("Problem Statement", 1),
    P("A retail analytics team selling through an online marketplace needs to answer three recurring questions every week: how much did we sell, which categories and states are underperforming on delivery, and which customers are worth retaining. The raw data arrives as six flat files per batch (orders, order items, customers, products, payments, reviews) and is not fit to query directly: order IDs repeat when a status update resends a row, roughly 1 in 68 order rows has a broken key or an impossible date, and text fields like state and payment type are inconsistently cased across batches."),
    P("Named users of this project are a retail operations analyst who needs daily revenue and delivery-delay numbers without writing PySpark, and a data engineer who needs the same numbers to reconcile exactly back to the source files when a stakeholder asks \u201cwhere did this number come from.\u201d Both currently rely on ad hoc spreadsheet pulls that cannot be reproduced or audited."),
    H2("Success criteria (testable)"),
    bullet(`Every row in the six source files is accounted for in Silver, in the quarantine table, or replaced by a later update \u2014 verified by test T08 (${passN}/16 tests passing overall).`),
    bullet(`Gold revenue matches an independent recalculation from the raw CSVs to the cent \u2014 verified by test T09, and by the two-stage waterfall in test T10.`),
    bullet("Re-running the full load three times and the incremental load twice produces identical row counts each time \u2014 verified by test T11 (idempotency)."),
    bullet("An analyst with read-only Snowflake access can answer all 10 business questions in snowflake/04_analysis_queries.sql without touching Databricks."),
    bullet("The pipeline completes a full load of 100,000+ orders on a laptop-class machine (1 CPU core, 4 GB RAM) in under three minutes."),
  ];
}

function sec2() {
  const rows = [
    ["Generate synthetic sales data that mirrors the structure and problems of a real e-commerce export", "Section 4 (dataset), data/generate_dataset.py"],
    ["Clean and validate the data with explicit, testable rules rather than silent coercion", "Section 9 (quality rules), Section 8 (tests T02\u2013T07)"],
    ["Aggregate into business-ready Gold tables that answer specific questions", "Section 5 (Gold grain), Section 10 (charts from Gold)"],
    ["Load Gold data into Snowflake with a warehouse sized and auto-suspended for a student budget", "Section 6, snowflake/01_setup_warehouse_roles.sql"],
    ["Support both a full reload and an incremental refresh without duplicating or losing rows", "Section 8 test T12, Section 9"],
    ["Prove the numbers are correct, not just \u201cthe code ran\u201d", "Section 9 (reconciliation), Section 8 (16 tests)"],
  ];
  return [
    H1("Objectives and Scope", 2),
    table(["Objective", "Where it is measured"], rows, [5600, 3750]),
    H2("In scope / out of scope"),
    table(["In scope", "Out of scope"], [
      ["Full and incremental medallion pipeline (Bronze/Silver/Gold)", "Real-time streaming ingestion (data arrives in daily-style batches)"],
      ["Data quality rules with a quarantine table and reasons", "A ML model for churn or demand forecasting"],
      ["Snowflake warehouse, RBAC, stream + task incremental refresh", "Multi-region or multi-account Snowflake setup"],
      ["Streamlit dashboard and a static HTML dashboard, both from Gold", "User authentication or row-level security on the dashboards"],
      ["Automated test suite with an independent revenue recalculation", "Automated CI/CD (documented as a future improvement in Section 12)"],
    ], [4675, 4675]),
  ];
}

function sec3() {
  return [
    H1("Solution and Features", 3),
    P("The project follows the medallion pattern. Databricks notebooks read the raw CSVs into Bronze exactly as received, apply typed and validated rules to produce Silver, and aggregate Silver into seven Gold tables. A loader notebook pushes Gold to Snowflake, where a stream and two chained tasks keep a curated order-line table and a daily revenue table refreshed automatically. Two dashboards \u2014 a Streamlit app and a single self-contained HTML page \u2014 read the same Gold tables so the numbers never disagree."),
    H2("Key features"),
    bullet("Bronze keeps every column as text and adds a content hash (_row_id) so exact duplicate rows are detected without relying on a database sequence."),
    bullet("Silver applies eight validation rules (null keys, unparseable timestamps, delivery-before-purchase, non-positive amounts, out-of-range review scores, duplicate keys, orphan foreign keys) and routes failures to a single quarantine table with a reason code."),
    bullet("Gold has seven tables, each with a stated grain and business question (Section 5)."),
    bullet("A Snowflake stream and two chained tasks (MERGE into CURATED, then into ANALYTICS.DAILY_SALES) give a 5-minute incremental refresh without a full reload."),
    bullet("ANALYST_ROLE can query CURATED and ANALYTICS but cannot modify a table, resize the warehouse, or see RAW.QUARANTINE \u2014 proved by 8 negative tests in snowflake/05_security_tests.sql."),
    bullet("Every number in this report was produced by five real executions of local_run/run_pipeline_local.py, logged to outputs/run_history.json, and checked by 16 automated tests in tests/test_pipeline.py."),
  ];
}

function sec4() {
  return [
    H1("Tech Stack", 4),
    table(["Technology", "Purpose in this project", "Why it was chosen"], [
      ["Python 3.12 / PySpark 4.x", "Bronze/Silver/Gold transformation logic", "Same DataFrame API runs locally and on a Databricks cluster with no code changes"],
      ["Delta Lake (Databricks) / Parquet (local)", "Storage format for each layer", "Delta gives ACID MERGE and time travel in the cloud; Parquet is the closest laptop equivalent"],
      ["Snowflake", "Cloud warehouse for curated data and analysis", "Streams + tasks give incremental refresh without a scheduler outside the warehouse"],
      ["Streamlit + Altair", "Interactive dashboard with a month-range filter", "Pure Python UI, deploys from a GitHub repo with no separate frontend build"],
      ["Plain HTML + inline SVG (no framework)", "Static, hostable dashboard", "Zero build step, deploys to Netlify/Vercel/GitHub Pages as a single file"],
      ["pandas + NumPy", "Synthetic data generation, gold CSV export", "Vectorised generation of 100,000+ realistic, seeded rows"],
      ["DuckDB", "Independent SQL logic check of the 10 analysis queries", "Runs the exact Snowflake SQL file against the Gold tables with no Snowflake account needed"],
      ["Graphviz + Matplotlib + Pillow", "Architecture/ER/flow diagrams and report charts", "Diagrams stay text-defined and reproducible from a script, not hand-drawn"],
    ], [2600, 3550, 3200]),
  ];
}

function sec5() {
  const manifest = require(require("path").join(__dirname, "..", "..", "data", "injection_manifest.json"));
  return [
    H1("Data Architecture and Layer Design", 5),
    H2("5.1 Dataset"),
    P("The dataset is generated by data/generate_dataset.py with a fixed NumPy seed of 42. It is not the real Kaggle Olist file; it follows the same six-table structure (orders, order_items, customers, products, payments, reviews) and the same rough scale and value ranges, so the pipeline logic transfers directly to the real dataset. Running the script again reproduces the same files byte-for-byte."),
    P("100,000 base orders were generated across January 2017 to August 2018, plus a 600-order incremental batch dated September 2018 that simulates a following week's load, including 40 orders that flip from \u2018shipped\u2019 to \u2018delivered\u2019 (to exercise the MERGE / upsert logic). Problems were injected on purpose and their exact counts are written to data/injection_manifest.json, which test T05 checks the quarantine table against row for row: " + manifest.orders.duplicate_rows + " duplicate order rows, " + (manifest.orders.null_order_id + manifest.orders.null_customer_id) + " null-key rows, " + manifest.orders.unparseable_purchase_ts + " unparseable timestamps, " + manifest.orders.delivered_before_purchase + " deliveries dated before their purchase, plus negative payments, out-of-range review scores, and inconsistent casing in state, status, category and payment-type fields."),
    H2("5.2 Layers"),
    table(["Layer", "Format", "What changes here", "Refresh"], [
      ["Bronze", "Delta (cloud) / Parquet (local)", "None \u2014 raw text plus lineage columns (_source_file, _row_id, _batch_id, _ingested_at)", "Full: overwrite. Incremental: insert only unseen _row_id"],
      ["Silver", "Delta / Parquet", "Typed, trimmed, standardised casing, de-duplicated on business key, validated, orphans removed", "Full: overwrite. Incremental: MERGE (upsert) on business key"],
      ["Gold", "Delta / Parquet", "Aggregated to the grains in the table below", "Always rebuilt in full from Silver \u2014 cheap enough not to need MERGE"],
    ], [1650, 2200, 3900, 1600]),
    H2("5.3 Gold tables: grain and business question"),
    table(["Table", "Grain (one row per...)", "Business question"], [
      ["daily_sales", "calendar day", "How much revenue and how many orders did each day bring?"],
      ["top_categories", "category \u00d7 month", "Which categories sell best, and does the ranking change month to month?"],
      ["delivery_performance", "customer state \u00d7 month", "Where are deliveries late, and by how many days?"],
      ["customer_rfm", "customer (unique_id)", "Who bought recently, often, and for the most money?"],
      ["order_status_mix", "order status", "What share of orders ends in each status?"],
      ["payment_type_summary", "payment type", "How do customers pay, and with how many installments?"],
      ["fact_order_lines", "order \u00d7 order item", "The line-level fact table the other six are built from"],
    ], [2000, 2600, 4750]),
    H2("5.4 Relationships"),
    P("customers 1\u2013N orders 1\u2013N order_items N\u20131 products; orders 1\u2013N payments; orders 1\u20130..N reviews. The full column list and these relationships for Silver, plus how each Gold table derives from them, are in Figure 6.2."),
  ];
}

function sec6() {
  return [
    H1("System Architecture", 6),
    ...figure("architecture.png", 640, "Figure 6.1: Source files to Databricks (Bronze/Silver/Gold) to Snowflake (RAW/CURATED/ANALYTICS) to the three consumers"),
    P("Data flows one direction only. Source CSVs are read into Bronze exactly as received. Silver cleaning splits every row into either the typed table or the quarantine table with a reason. Gold aggregates Silver. A loader notebook pushes fact_order_lines into Snowflake RAW as an append-only landing table and replaces the six summary tables in ANALYTICS directly. A stream on the landing table feeds a task that MERGEs into CURATED.ORDER_LINES, and a second chained task recomputes ANALYTICS.DAILY_SALES for the affected days only."),
    ...figure("er_diagram.png", 640, "Figure 6.2: Table relationships in Silver (source of truth) and how Gold is derived from them"),
    ...figure("pipeline_flow.png", 480, "Figure 6.3: Five quality checkpoints. CP1\u2013CP3 are asserted locally by tests/test_pipeline.py and on Databricks by notebook 05; a failure at any checkpoint stops the job before the Snowflake load."),
  ];
}

function sec7() {
  const dedupe = `def _dedupe(df, keys):
    """Keep one row per business key. Extra copies come back tagged for quarantine."""
    w = Window.partitionBy(*keys).orderBy("_row_id")
    r = df.withColumn("_rn", F.row_number().over(w))
    return (r.filter("_rn = 1").drop("_rn"),
            r.filter("_rn > 1").drop("_rn").withColumn("_reason", F.lit("DUPLICATE_KEY")))`;
  const ts = `def _ts(c):
    # Spark 4 runs with ANSI mode on: plain to_timestamp raises on a bad string
    # instead of returning null, and one bad row would crash the whole job.
    return F.expr(f"try_to_timestamp({c}, '{"yyyy-MM-dd HH:mm:ss"}')")`;
  const rfm = `# customer id breaks ties so ntile gives the same 5 buckets on every run
r = F.ntile(5).over(Window.orderBy(F.col("recency_days").desc(), "customer_unique_id"))
m = F.ntile(5).over(Window.orderBy(F.col("monetary").asc(), "customer_unique_id"))`;
  return [
    H1("Implementation Highlights", 7),
    H2("7.1 De-duplication that quarantines the extra copies instead of silently dropping them"),
    P("Every table is de-duplicated on its business key by numbering rows within the key using the content-hash row id as a stable tiebreaker. The first copy is kept in Silver; every extra copy is tagged DUPLICATE_KEY and sent to quarantine instead of being discarded, so the count of injected duplicates in the manifest matches the quarantine count exactly (test T05)."),
    codeBlock(dedupe),
    H2("7.2 Working around Spark 4's ANSI mode on a bad timestamp"),
    P("The first full run crashed with a DateTimeException on a deliberately unparseable timestamp (\u201831/02/2018 10:00\u2019, injected on purpose). Spark 4 runs in ANSI mode by default, so to_timestamp() raises instead of returning null. The fix uses try_to_timestamp, which returns null on a bad value so the row is caught by the INVALID_TIMESTAMP rule and quarantined instead of crashing the job. See the full account in Section 11."),
    codeBlock(ts),
    H2("7.3 Deterministic RFM segmentation"),
    P("Window.orderBy() with no tiebreaker can assign a different ntile bucket to two customers with an identical value on different runs. Ordering by customer_unique_id as a secondary key makes the five recency and monetary buckets identical on every re-run \u2014 verified by test T11, which compares three full-load runs row for row."),
    codeBlock(rfm),
  ];
}

function codeBlock(text) {
  const lines = text.split("\n");
  return new Table({
    width: { size: 9350, type: WidthType.DXA }, columnWidths: [9350],
    borders: { top: { style: BorderStyle.SINGLE, size: 4, color: "3b4650" }, bottom: { style: BorderStyle.SINGLE, size: 4, color: "3b4650" }, left: { style: BorderStyle.SINGLE, size: 4, color: "3b4650" }, right: { style: BorderStyle.SINGLE, size: 4, color: "3b4650" }, insideHorizontal: { style: BorderStyle.NONE }, insideVertical: { style: BorderStyle.NONE } },
    rows: [new TableRow({ children: [new TableCell({
      width: { size: 9350, type: WidthType.DXA }, shading: { fill: "101820", type: ShadingType.CLEAR }, margins: { top: 160, bottom: 160, left: 220, right: 220 },
      children: lines.map(l => new Paragraph({ spacing: { after: 20 }, children: [new TextRun({ text: l.length ? l : " ", font: "Consolas", size: 17, color: "d6dee6" })] })),
    })] })],
  });
}

function sec8() {
  const rows = [
    ["T01", "Bronze row count equals source files (main + incremental)", "Count CSV lines vs Bronze rows", "PASS", "All 6 tables match exactly"],
    ["T02", "No null keys in Silver", "isna() on key columns", "PASS", "0 rows"],
    ["T03", "No duplicate business keys in Silver", "duplicated() on business key", "PASS", "0 rows"],
    ["T04", "No delivery date before purchase date in Silver", "Compare timestamps", "PASS", "0 rows"],
    ["T05", "Every injected problem caught in the exact injected count", "Quarantine reasons vs injection_manifest.json", "PASS", "12 of 12 rules match exactly"],
    ["T06", "Text casing standardised (state, status, payment type, category)", "Regex / set checks on Silver", "PASS", "One spelling per value"],
    ["T07", "No zero or negative price or payment in Silver", "Filter on amounts", "PASS", "0 rows"],
    ["T08", "Every Bronze row is in Silver, quarantine, or replaced by an update", "bronze \u2212 silver \u2212 quarantine per table", "FAIL then PASS", "First incremental run: 4 tables under-counted (bug below). Fixed, then 0 unaccounted (40 orders correctly replaced)"],
    ["T09", "Gold revenue equals revenue recalculated independently in pandas", "Separate pandas re-implementation of the rules on the raw CSVs", "FAIL then PASS", "First run: \u20b985,000 gap from the same bug. After the fix: difference R$ 0.00"],
    ["T10", "Revenue waterfall balances end to end", "Decimal sums logged by the pipeline itself", "PASS", "Both identities true (Section 9.3)"],
    ["T11", "Re-running the pipeline gives identical counts (idempotent)", "Compare 3 full runs and 2 incremental runs", "PASS", "All full runs identical; both incremental runs identical"],
    ["T12", "Incremental MERGE inserts new rows and updates changed ones without duplicating", "Compare Silver before/after the incremental batch", "FAIL then PASS", "First run: +0 new orders (bug). After the fix: +600 new, 40 updated to \u2018delivered\u2019, 0 duplicates"],
    ["T13", "customer_rfm has one row per customer and sums to Gold revenue", "Uniqueness + segment set + sum check", "PASS", "88,714 unique customers, 6 segments"],
    ["T14", "delivery_performance values are within valid ranges", "Range checks on late_pct, late_orders \u2264 delivered", "PASS", "531 state-month rows, all in range"],
    ["T15", "Rule unit test on 6 hand-built rows, incl. the bad date that crashed run 1", "clean_orders() on a small in-memory DataFrame", "PASS", "2 kept, 4 quarantined with the exact expected reasons"],
    ["T16", "All 10 analysis queries run and return rows outside Snowflake", "Run snowflake/04_analysis_queries.sql on Gold via DuckDB", "FAIL then PASS", "First run: a DECIMAL overflow in the test harness (not the SQL). Fixed; 10 of 10 return rows"],
  ];
  return [
    H1("Testing", 8),
    P(`16 automated test cases in tests/test_pipeline.py, run against the real output of five pipeline executions (Section 9.4). ${passN} of 16 passed on the final run; four tests failed on their first run and are recorded honestly below, with the real bug and the real fix (also detailed in Section 11).`),
    table(["#", "Test case", "Method", "Result", "Detail"], rows.map(r => [r[0], r[1], r[2], r[3], r[4]]), [500, 2650, 2150, 1300, 2750]),
    ...figure("out_test_results.png", 480, "Figure 9.6: full test run, final state \u2014 16 of 16 passed"),
  ];
}

function sec9() {
  const qr = fullRuns[fullRuns.length - 1].quality_rules;
  const qrRows = qr.map(r => [r.rule, r.checked.toLocaleString(), r.failed.toLocaleString(), r.pass_rate.toFixed(2) + "%"]);
  const stageRows = H.map((h, i) => [i + 1, h.mode, h.total_seconds.toFixed(1) + " s", h.stage_seconds.bronze.toFixed(1), h.stage_seconds.silver.toFixed(1), h.stage_seconds.gold.toFixed(1), h.stage_seconds.quality.toFixed(1)]);
  return [
    H1("Data Quality and Performance Results", 9),
    P("All results below come from outputs/run_metrics.json and outputs/run_history.json, written automatically by local_run/run_pipeline_local.py on every execution. The pipeline was run five times end to end: three full loads (to test idempotency) and two incremental loads (to test the upsert logic and its own idempotency)."),
    H2("9.1 Row counts per layer (after the full load, then after the incremental load)"),
    ...figure("out_row_counts.png", 460, "Figure 9.1: Bronze and Silver row counts, full load vs after the incremental batch"),
    H2("9.2 Data quality rule results (full load)"),
    table(["Rule", "Rows checked", "Rows failed", "Pass rate"], qrRows, [4200, 1800, 1550, 1800]),
    ...figure("out_quality_rules.png", 460, "Figure 9.2: the same 15 rules as rendered by the pipeline's own summary"),
    H2("9.3 Revenue reconciliation (source file to Gold, after both loads)"),
    P(`Source file item revenue: R$ ${Number(R.source_raw_revenue).toLocaleString("en-IN",{minimumFractionDigits:2,maximumFractionDigits:2})}. Quarantined (excluded from Silver): R$ ${Number(R.quarantined_total).toLocaleString("en-IN",{minimumFractionDigits:2,maximumFractionDigits:2})} across null keys, duplicates, invalid amounts and orphan rows. Silver revenue: R$ ${Number(R.silver_revenue).toLocaleString("en-IN",{minimumFractionDigits:2,maximumFractionDigits:2})}. Excluded as cancelled/unavailable orders (never counted as revenue): R$ ${Number(R.excluded_canceled_unavailable).toLocaleString("en-IN",{minimumFractionDigits:2,maximumFractionDigits:2})}. Gold daily_sales revenue: R$ ${Number(R.gold_revenue).toLocaleString("en-IN",{minimumFractionDigits:2,maximumFractionDigits:2})}. Both balancing identities hold exactly: source = quarantined + Silver (${R.source_equals_quarantine_plus_silver}), and Silver = Gold + excluded statuses (${R.silver_equals_gold_plus_excluded}).`),
    ...figure("out_reconciliation.png", 420, "Figure 9.3: the waterfall as printed by the pipeline after the incremental run"),
    H2("9.4 / 9.5 Run history and stage timings (five executions, 1 CPU core / 4 GB RAM sandbox)"),
    table(["Run", "Mode", "Total", "Bronze (s)", "Silver (s)", "Gold (s)", "Quality (s)"], stageRows, [800, 1750, 1300, 1400, 1300, 1200, 1600]),
    ...figure("out_run_history.png", 620, "Figure 9.4: run history log"),
    ...figure("out_timings.png", 400, "Figure 9.5: stage timings across all five runs"),
    P("Every full load completed in 105\u2013127 seconds and every incremental load in 73\u201377 seconds, well inside the 3-minute target in Section 1. Bronze is the slowest stage because it re-reads and re-hashes every source row; Silver and Gold are each under 20 seconds on the incremental path."),
  ];
}

function sec10() {
  const charts = [
    ["chart_monthly_revenue.png", "10.1", "Monthly revenue trend, January 2017 to September 2018. November 2017 shows a clear spike (Black Friday effect built into the generator); September 2018 is a partial month (the 7-day incremental batch)."],
    ["chart_top_categories.png", "10.2", "Top 10 categories by revenue over the whole period, from top_categories."],
    ["chart_delivery_delay_state.png", "10.3", "The 12 worst states by average delivery delay (states with at least 500 delivered orders), from delivery_performance."],
    ["chart_rfm_segments.png", "10.4", "Customer counts and revenue by RFM segment, from customer_rfm."],
    ["chart_order_status.png", "10.5", "Order status mix on a log scale, because delivered orders are 97% of the total."],
    ["chart_payment_types.png", "10.6", "Payment types by share of value and average installment count."],
    ["chart_quarantine_reasons.png", "10.7", "Rows quarantined by table and reason, matching the injection manifest in Section 5.1."],
  ];
  const body = [H1("Screenshots and Visual Results", 10)];
  for (const [f, n, cap] of charts) body.push(...figure(f, 560, `Figure ${n}: ${cap}`));
  body.push(H2("10.8 \u2013 10.9 Dashboards"));
  body.push(...figure("streamlit_dashboard.png", 620, "Figure 10.8: the Streamlit dashboard (dashboard/app.py), running live against the Gold CSV files with a month-range filter"));
  body.push(...figure("static_site.png", 560, "Figure 10.9: the static HTML dashboard (site/index.html), the version published as the live hosted link"));
  body.push(H2("10.10 \u2013 10.15 Cloud screenshots"));
  body.push(P("The six cloud screenshots below (Databricks job run, Snowsight query results, and the Stream/Task history) can only be captured from a live Databricks workspace and Snowflake account, which this environment does not have. Six correctly sized slots and numbered instructions are in screenshots/CAPTURE_GUIDE.md; capturing all six takes about 20 minutes."));
  const slotNames = ["10.10 Databricks job run (all 5 notebooks green)", "10.11 Databricks job run details / cluster", "10.12 Snowsight: 04_analysis_queries.sql results", "10.13 Snowsight: SHOW TASKS / task history", "10.14 Snowsight: warehouse size and auto-suspend", "10.15 Snowsight: 05_security_tests.sql failures as ANALYST_ROLE"];
  const rows = [];
  for (let i = 0; i < slotNames.length; i += 2) rows.push([slotNames[i], slotNames[i + 1] || ""]);
  body.push(new Table({
    width: { size: 9350, type: WidthType.DXA }, columnWidths: [4675, 4675],
    borders: { top: { style: BorderStyle.SINGLE, size: 4, color: LINE }, bottom: { style: BorderStyle.SINGLE, size: 4, color: LINE }, left: { style: BorderStyle.SINGLE, size: 4, color: LINE }, right: { style: BorderStyle.SINGLE, size: 4, color: LINE }, insideHorizontal: { style: BorderStyle.SINGLE, size: 2, color: LINE }, insideVertical: { style: BorderStyle.SINGLE, size: 2, color: LINE } },
    rows: rows.map(r => new TableRow({ children: r.map(t => new TableCell({
      width: { size: 4675, type: WidthType.DXA }, margins: { top: 700, bottom: 700, left: 160, right: 160 },
      shading: { fill: "F5F8FA", type: ShadingType.CLEAR },
      children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: t || "", italics: true, color: MUT, size: 18, font: "Calibri" })] })],
    })) })),
  }));
  return body;
}

function sec11() {
  const rows = [
    ["Full run crashed: DateTimeException on an unparseable timestamp ('31/02/2018 10:00', injected on purpose)", "Spark 4 runs with ANSI mode on by default, so to_timestamp() raises on a bad string instead of returning null the way earlier Spark versions did", "Switched to try_to_timestamp() (and try_cast() for numeric fields), which returns null on a bad value so the row is caught by the validation rule and quarantined instead of crashing the job"],
    ["First incremental run: 4 tables silently under-counted \u2014 Bronze grew by 640 orders but Silver stayed flat, and revenue tests T09/T10 were off by about R$85,000", "The 'new rows' DataFrame was a lazy Spark transformation defined against the Bronze folder. After that folder was overwritten with existing+new rows, Spark re-evaluated the lazy anti-join against the new folder and found nothing left unseen, so an empty batch reached Silver", "Materialise the new rows to a separate Parquet folder (bronze_new) before touching Bronze at all, then read them back from disk and extend Bronze from that fixed snapshot"],
    ["Test harness (not the pipeline) crashed with a DECIMAL overflow when running the 10 Snowflake queries through DuckDB", "DuckDB inferred a narrow DECIMAL(5,2) from a Gold Parquet column and overflowed on a SUM() of a much larger intermediate value", "Cast Decimal-typed Gold columns to DOUBLE only inside the test harness before loading them into DuckDB; the SQL file itself was not changed"],
    ["Report's flow diagram was unreadably wide when rendered by Graphviz's automatic layout", "The five-stage pipeline with five checkpoints does not lay out well left-to-right at a printable page width", "Redrew it as a fixed three-row snake layout (Figure 6.3) with hand-placed coordinates instead of relying on automatic graph layout"],
  ];
  return [
    H1("Challenges and Fixes", 11),
    P("Four real problems were hit while building this project, in the order they happened. Each is recorded honestly with its cause and its fix, and the first two are also covered as code excerpts in Section 7."),
    table(["Problem", "Root cause", "Fix"], rows, [2950, 3200, 3200]),
    H2("Key learning"),
    P("Type inference and null-coercion behaviour are not constant across Spark versions \u2014 code written for an older ANSI-off default can crash outright on Spark 4 instead of degrading gracefully. Lazy evaluation is also easy to get wrong when a DataFrame is defined against a path that a later step overwrites; materialising to a fixed snapshot before continuing avoided a second, harder-to-spot bug class (silently wrong results rather than a crash)."),
  ];
}

function sec12() {
  return [
    H1("Future Improvements", 12),
    bullet("Add a Databricks Job with a schedule and email/Slack alert on failure, instead of running notebooks by hand.", { bold: false }),
    bullet("Replace the local MERGE-by-join in run_pipeline_local.py with real Delta Lake MERGE once a local Delta-OSS setup with Maven access is available, so the local run matches Databricks even more closely."),
    bullet("Add a seventh Gold table for cohort retention (first-purchase month vs. repeat-purchase month) to extend the customer_rfm analysis."),
    bullet("Add row-level security in Snowflake so ANALYST_ROLE only sees customer_state rows for their assigned region."),
    bullet("Wire GitHub Actions to run tests/test_pipeline.py on every push, so a broken rule is caught before merging rather than in the next manual run."),
  ];
}

function sec13() {
  return [
    H1("Conclusion", 13),
    P(`This project built and actually ran a full medallion pipeline on a 102,140-row synthetic order dataset shaped like Olist, end to end, five separate times, producing seven Gold tables that reconcile exactly back to the source files (Section 9.3). ${passN} of 16 automated tests pass on the final run; the four that failed on their first attempt are documented with their real cause and real fix rather than hidden (Sections 8 and 11). The pipeline is idempotent across three full loads and two incremental loads, completes well inside the 3-minute target, and every chart and terminal screenshot in this report was generated from that real output, not from illustrative numbers.`),
    P("The project met the objectives in Section 2: the data is cleaned with explicit and testable rules rather than silent coercion, Gold answers the specific questions it was designed for, Snowflake access is role-separated and auto-suspending, and the incremental path is proven correct rather than assumed correct."),
  ];
}

function sec14() {
  return [
    H1("References and Links", 14),
    table(["Item", "Details"], [
      ["GitHub repository", `https://github.com/${GH}/customer-analytics-snowflake-databricks`],
      ["Live dashboard (static)", "[fill in after deploying site/ to Netlify, Vercel or GitHub Pages \u2014 see DEPLOY.md]"],
      ["Dataset", "Synthetic, generated by data/generate_dataset.py (seed 42), structured like the Olist Brazilian E-Commerce dataset on Kaggle (https://www.kaggle.com/datasets/olistbr/brazilian-ecommerce). Not the real Kaggle file \u2014 see Section 5.1."],
      ["Documentation used", "Apache Spark / PySpark documentation, Delta Lake documentation, Snowflake documentation (streams, tasks, RBAC), Streamlit documentation, DuckDB documentation"],
      ["Demo video script", "docs/DEMO_SCRIPT.md (2\u20133 minutes, timestamped)"],
    ], [2800, 6550]),
  ];
}

function checklistPage() {
  const items = [
    ["Cover page filled in with real name, roll number, trainer and date", false],
    ["All 14 sections present, following the required structure", true],
    ["Every number in Sections 8\u20139 produced by an executed run, not invented", true],
    [`Test suite run and results recorded honestly (${passN}/16 passing, 4 historical failures documented)`, true],
    ["Pipeline re-run 3x full + 2x incremental to prove idempotency (Section 9.4)", true],
    ["Revenue reconciled from source file to Gold table (Section 9.3)", true],
    ["Architecture, ER and pipeline-flow diagrams included (Section 6)", true],
    ["At least 6 real charts from Gold data included (Section 10, 7 provided)", true],
    ["Dashboard screenshots captured from a running app (Streamlit + static site)", true],
    ["6 cloud screenshots (Databricks + Snowsight) captured", false],
    ["GitHub repository created and code pushed", false],
    ["Static dashboard deployed and live link added to Section 14", false],
    ["Demo video recorded using docs/DEMO_SCRIPT.md", false],
  ];
  return [
    H1("Submission Checklist"),
    table(["Item", "Status"], items.map(([t, done]) => [t, done ? "\u2713 Done" : "\u25a1 To do"]), [7550, 1800]),
  ];
}

// ---------------- assemble ----------------
const headerFooter = {
  header: new Header({ children: [new Paragraph({
    border: { bottom: { color: LINE, space: 4, style: BorderStyle.SINGLE, size: 4 } },
    tabStops: [{ type: "right", position: convertInchesToTwip(6.5) }],
    children: [new TextRun({ text: "AI... ", size: 2, color: "FFFFFF" }), new TextRun({ text: "Customer Data Analytics \u2014 Capstone Report", italics: true, size: 17, color: MUT, font: "Calibri" }),
      new TextRun({ text: "\t", size: 17 }), new TextRun({ text: "Databricks & Snowflake 2026", size: 17, color: MUT, font: "Calibri" })],
  })] }),
  footer: new Footer({ children: [new Paragraph({
    alignment: AlignmentType.CENTER, border: { top: { color: LINE, space: 4, style: BorderStyle.SINGLE, size: 4 } },
    children: [new TextRun({ text: "Page ", size: 17, color: MUT, font: "Calibri" }), new TextRun({ children: [PageNumber.CURRENT], size: 17, color: MUT, font: "Calibri" }),
      new TextRun({ text: " of ", size: 17, color: MUT, font: "Calibri" }), new TextRun({ children: [PageNumber.TOTAL_PAGES], size: 17, color: MUT, font: "Calibri" })],
  })] }),
};

const doc = new Document({
  creator: NAME, title: "Customer Data Analytics using Snowflake and Databricks",
  numbering: { config: [{ reference: "bullets", levels: [{ level: 0, format: "bullet", text: "\u2022", alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 420, hanging: 260 } } } }] }] },
  styles: { default: { document: { run: { font: "Calibri", size: 21 } } } },
  sections: [
    { properties: { page: { size: { width: 12240, height: 15840 }, margin: { top: 1100, bottom: 1100, left: 1150, right: 1150 } } }, children: coverPage() },
    { properties: { page: { size: { width: 12240, height: 15840 }, margin: { top: 1100, bottom: 1100, left: 1150, right: 1150 } }, }, headers: headerFooter.header ? { default: headerFooter.header } : undefined, footers: { default: headerFooter.footer }, children: [...tocPage(), ...lofPage()] },
    {
      properties: { page: { size: { width: 12240, height: 15840 }, margin: { top: 1100, bottom: 1100, left: 1150, right: 1150 } } },
      headers: { default: headerFooter.header }, footers: { default: headerFooter.footer },
      children: [
        ...sec1(), ...sec2(), ...sec3(), ...sec4(), ...sec5(), ...sec6(), ...sec7(), ...sec8(), ...sec9(), ...sec10(), ...sec11(), ...sec12(), ...sec13(), ...sec14(),
        new Paragraph({ children: [new PageBreak()] }), ...checklistPage(),
      ],
    },
  ],
});

Packer.toBuffer(doc).then(buf => {
  const out = require("path").join(__dirname, "..", "AI_Content... ");
  const outPath = require("path").join(__dirname, "..", "Customer_Data_Analytics_Snowflake_Databricks_Report.docx");
  fsn.writeFileSync(outPath, buf);
  console.log("wrote", outPath, (buf.length / 1024).toFixed(0), "KB");
});
