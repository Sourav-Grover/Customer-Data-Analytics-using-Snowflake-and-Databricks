const fs = require("fs");
const path = require("path");
const {
  Document, Packer, Paragraph, TextRun, HeadingLevel, Table, TableRow, TableCell,
  WidthType, ShadingType, BorderStyle, AlignmentType, ImageRun, PageBreak, Header, Footer,
  PageNumber, NumberOfPages, TabStopType, TabStopPosition, LevelFormat, convertInchesToTwip,
  VerticalAlign, PageOrientation, ExternalHyperlink, TableOfContents, SectionType
} = require("docx");

const ASSETS = path.join(__dirname, "..", "assets");
const NAVY = "0b5c8f", TEAL = "1a8a8a", GOLD = "c48a10", RED = "b3372f", GREEN = "2b8a4b", INK = "26313a", MUT = "5a6672", LINE = "c9d1d9", SOFT = "eef4fa";

function img(name, widthPx, opts = {}) {
  const p = path.join(ASSETS, name);
  const buf = fs.readFileSync(p);
  const sizeOf = require("image-size").default || require("image-size");
  const dim = sizeOf(buf);
  const w = widthPx;
  const h = Math.round(w * dim.height / dim.width);
  return new ImageRun({ type: "png", data: buf, transformation: { width: w, height: h }, ...opts });
}

function P(text, opts = {}) {
  const { bold, italic, size, color, spacingBefore, spacingAfter, align, indent } = opts;
  return new Paragraph({
    alignment: align,
    spacing: { before: spacingBefore || 0, after: spacingAfter !== undefined ? spacingAfter : 120 },
    indent: indent ? { left: indent } : undefined,
    children: [new TextRun({ text, bold, italics: italic, size: size || 21, color: color || INK, font: "Calibri" })],
  });
}

function Runs(parts, opts = {}) {
  return new Paragraph({
    spacing: { before: opts.spacingBefore || 0, after: opts.spacingAfter !== undefined ? opts.spacingAfter : 120 },
    children: parts.map(p => new TextRun({ text: p.text, bold: p.bold, italics: p.italic, color: p.color || INK, size: p.size || 21, font: "Calibri" })),
  });
}

function H1(text, num) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_1,
    spacing: { before: 340, after: 160 },
    border: { bottom: { color: NAVY, space: 4, style: BorderStyle.SINGLE, size: 10 } },
    children: [new TextRun({ text: (num ? num + ". " : "") + text, bold: true, color: NAVY, size: 30, font: "Calibri" })],
  });
}
function H2(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_2,
    spacing: { before: 240, after: 120 },
    children: [new TextRun({ text, bold: true, color: TEAL, size: 24, font: "Calibri" })],
  });
}
function bullet(text, opts = {}) {
  return new Paragraph({
    numbering: { reference: "bullets", level: 0 },
    spacing: { after: 80 },
    children: [new TextRun({ text, size: 21, color: INK, font: "Calibri", bold: opts.bold })],
  });
}
function caption(text) {
  return new Paragraph({
    alignment: AlignmentType.CENTER,
    spacing: { before: 80, after: 220 },
    children: [new TextRun({ text, italics: true, size: 19, color: MUT, font: "Calibri" })],
  });
}
function figure(name, widthPx, capText, opts = {}) {
  return [
    new Paragraph({ alignment: AlignmentType.CENTER, spacing: { before: 160, after: 0 }, children: [img(name, widthPx, opts)] }),
    caption(capText),
  ];
}

function cell(text, opts = {}) {
  const { bold, shade, color, width, align, size, italic } = opts;
  return new TableCell({
    width: width ? { size: width, type: WidthType.DXA } : undefined,
    shading: shade ? { fill: shade, type: ShadingType.CLEAR } : undefined,
    verticalAlign: VerticalAlign.CENTER,
    margins: { top: 70, bottom: 70, left: 100, right: 100 },
    children: [new Paragraph({
      alignment: align || AlignmentType.LEFT,
      children: [new TextRun({ text: String(text), bold, italics: italic, color: color || INK, size: size || 19, font: "Calibri" })],
    })],
  });
}

function table(headers, rows, colWidths) {
  const total = colWidths.reduce((a, b) => a + b, 0);
  return new Table({
    width: { size: total, type: WidthType.DXA },
    columnWidths: colWidths,
    borders: {
      top: { style: BorderStyle.SINGLE, size: 4, color: LINE }, bottom: { style: BorderStyle.SINGLE, size: 4, color: LINE },
      left: { style: BorderStyle.SINGLE, size: 4, color: LINE }, right: { style: BorderStyle.SINGLE, size: 4, color: LINE },
      insideHorizontal: { style: BorderStyle.SINGLE, size: 2, color: LINE }, insideVertical: { style: BorderStyle.SINGLE, size: 2, color: LINE },
    },
    rows: [
      new TableRow({
        tableHeader: true,
        children: headers.map((h, i) => cell(h, { bold: true, shade: NAVY, color: "FFFFFF", width: colWidths[i], size: 18 })),
      }),
      ...rows.map((r, ri) => new TableRow({
        children: r.map((v, i) => cell(v, { width: colWidths[i], shade: ri % 2 ? "F5F8FA" : "FFFFFF", align: typeof v === "number" ? AlignmentType.RIGHT : undefined })),
      })),
    ],
  });
}

function pageNumFooter() {
  return new Footer({
    children: [new Paragraph({
      alignment: AlignmentType.CENTER,
      border: { top: { color: LINE, space: 4, style: BorderStyle.SINGLE, size: 4 } },
      children: [
        new TextRun({ text: "AI Content... ", color: "FFFFFF", size: 2 }), // placeholder unused
      ],
    })],
  });
}

module.exports = {
  fs, path, Document, Packer, Paragraph, TextRun, HeadingLevel, Table, TableRow, TableCell,
  WidthType, ShadingType, BorderStyle, AlignmentType, ImageRun, PageBreak, Header, Footer,
  PageNumber, NumberOfPages, TabStopType, TabStopPosition, LevelFormat, convertInchesToTwip,
  VerticalAlign, PageOrientation, ExternalHyperlink, TableOfContents, SectionType,
  img, P, Runs, H1, H2, bullet, caption, figure, cell, table,
  NAVY, TEAL, GOLD, RED, GREEN, INK, MUT, LINE, SOFT, ASSETS,
};
