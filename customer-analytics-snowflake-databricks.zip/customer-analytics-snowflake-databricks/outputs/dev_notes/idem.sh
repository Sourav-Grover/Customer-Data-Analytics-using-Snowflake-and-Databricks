#!/bin/bash
cd /home/claude/capstone
for m in full full full incremental incremental; do
  python3 local_run/run_pipeline_local.py --mode $m > outputs/run_$(date +%s)_$m.log 2>&1
  echo "done $m $(date +%T)" >> outputs/dev_notes/idem_progress.txt
done
echo ALLDONE >> outputs/dev_notes/idem_progress.txt
