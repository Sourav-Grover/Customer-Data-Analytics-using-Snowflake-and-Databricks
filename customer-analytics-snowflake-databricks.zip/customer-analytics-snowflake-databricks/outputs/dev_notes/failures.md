# Failures hit while building (recorded as they happened)
1. Full run, Silver orders: DateTimeException CANNOT_PARSE_TIMESTAMP on '31/02/2018 10:00'.
   Cause: Spark 4 runs with ANSI mode on, so to_timestamp raises instead of returning null.
   Fix: try_to_timestamp / try_cast in common/transforms.py.
2. tests/test_pipeline.py after the first incremental run: T08, T09, T10, T12 failed. Bronze grew by 640 orders but Silver stayed at 98,515.
   Cause: `fresh` (batch rows not yet in Bronze) was a lazy anti-join against the Bronze folder. After Bronze was overwritten with existing + fresh,
   Spark re-evaluated `fresh` against the new folder and found nothing, so Silver received an empty batch. The .cache() did not help because it had not been filled yet.
   Fix: write the new rows to outputs/lakehouse/bronze_new first and read them back from there, then extend Bronze.
3. T16 (DuckDB check of the 10 SQL queries): "Casting value 1004.04 to type DECIMAL(5,2) failed". DuckDB inferred a narrow decimal type from the parquet
   values and overflowed in SUM(avg_delay_days * delivered_orders). Fix in the test harness: load decimal columns as DOUBLE. The SQL file was not changed.
