"""
run_pipeline_local.py
Runs the whole Bronze -> Silver -> Gold pipeline on a laptop with plain PySpark, no cloud account.
The cleaning and aggregation code is imported from common/transforms.py, the same file the
Databricks notebooks use. The only differences from Databricks are the storage format (Parquet here,
Delta there) and the merge (join based here, Delta MERGE there).

    python local_run/run_pipeline_local.py                       # full load
    python local_run/run_pipeline_local.py --mode incremental    # upsert data/raw_increment
"""
import argparse
import json
import shutil
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from pyspark.sql import SparkSession, functions as F  # noqa: E402
from common import transforms as T  # noqa: E402
from common.quality import quality_rules, reconcile  # noqa: E402

LAKE = ROOT / "outputs" / "lakehouse"
TABLES = list(T.RAW_COLUMNS)


def get_spark():
    return (SparkSession.builder.master("local[*]").appName("customer-analytics-local")
            .config("spark.sql.shuffle.partitions", "8")
            .config("spark.sql.session.timeZone", "UTC")      # timestamps must not shift with the laptop's timezone
            .config("spark.ui.enabled", "false").config("spark.driver.memory", "2g").getOrCreate())


def write_table(spark, df, layer, name):
    """Overwrite a table. Writes to a temp folder first because in incremental mode the
    DataFrame being written is built from the folder it will replace."""
    path, tmp = LAKE / layer / name, LAKE / layer / f"{name}__tmp"
    if tmp.exists():
        shutil.rmtree(tmp)
    df.write.mode("overwrite").parquet(str(tmp))
    if path.exists():
        shutil.rmtree(path)
    tmp.rename(path)
    spark.catalog.refreshByPath(str(path))
    return spark.read.parquet(str(path))


def read_table(spark, layer, name):
    return spark.read.parquet(str(LAKE / layer / name))


def run(mode):
    log = []
    t_start = time.perf_counter()
    spark = get_spark()
    spark.sparkContext.setLogLevel("ERROR")
    stages, counts = {}, {"bronze": {}, "silver": {}, "gold": {}}

    def stage(name):
        class _S:
            def __enter__(s): s.t = time.perf_counter()
            def __exit__(s, *a): stages[name] = round(time.perf_counter() - s.t, 2)
        return _S()

    src_dir = ROOT / "data" / ("raw" if mode == "full" else "raw_increment")
    batch = "full_load" if mode == "full" else "inc_001"

    # ---------------- Bronze ----------------
    new_bronze = {}
    with stage("bronze"):
        for t in TABLES:
            df = T.read_bronze(spark, str(src_dir / f"{t}.csv"), t, batch)
            if mode == "full":
                new_bronze[t] = df
                write_table(spark, df, "bronze", t)
            else:
                existing = read_table(spark, "bronze", t)
                # insert only rows whose _row_id is not stored yet, so re-running the same batch adds nothing
                fresh = df.join(existing.select("_row_id"), "_row_id", "left_anti").select(existing.columns)
                # Stage the new rows on disk BEFORE touching Bronze. `fresh` is lazy: if it were re-evaluated after
                # Bronze is overwritten, the anti-join would find nothing and Silver would get an empty batch.
                new_bronze[t] = write_table(spark, fresh, "bronze_new", t)
                write_table(spark, existing.unionByName(new_bronze[t]), "bronze", t)
        for t in TABLES:
            counts["bronze"][t] = read_table(spark, "bronze", t).count()

    # ---------------- Silver ----------------
    with stage("silver"):
        quarantines = []
        if mode == "full":
            orders, q = T.clean_orders(new_bronze["orders"])
        else:
            n_orders, q = T.clean_orders(new_bronze["orders"])
            orders = T.upsert(read_table(spark, "silver", "orders"), n_orders, T.KEYS["orders"])
        quarantines.append(q)
        orders = write_table(spark, orders, "silver", "orders")

        def do(name, fn, *extra):
            new, q_ = fn(new_bronze[name], *extra)
            quarantines.append(q_)
            if mode == "incremental":
                new = T.upsert(read_table(spark, "silver", name), new, T.KEYS[name])
            return write_table(spark, new, "silver", name)

        customers = do("customers", T.clean_customers)
        products = do("products", T.clean_products)
        items = do("order_items", T.clean_items, orders)
        payments = do("payments", T.clean_payments, orders)
        reviews = do("reviews", T.clean_reviews, orders)

        newq = quarantines[0]
        for q_ in quarantines[1:]:
            newq = newq.unionByName(q_)
        if mode == "incremental":
            newq = read_table(spark, "silver", "quarantine").unionByName(newq)
        quarantine = write_table(spark, newq, "silver", "quarantine")
        for t in TABLES + ["quarantine"]:
            counts["silver"][t] = read_table(spark, "silver", t).count()

    # ---------------- Gold (always rebuilt from Silver) ----------------
    with stage("gold"):
        fact = write_table(spark, T.build_fact_lines(orders, items, customers, products), "gold", "fact_order_lines")
        daily = write_table(spark, T.gold_daily_sales(fact), "gold", "daily_sales")
        write_table(spark, T.gold_top_categories(fact), "gold", "top_categories")
        write_table(spark, T.gold_delivery_performance(orders, customers, reviews), "gold", "delivery_performance")
        write_table(spark, T.gold_customer_rfm(fact), "gold", "customer_rfm")
        write_table(spark, T.gold_order_status_mix(orders), "gold", "order_status_mix")
        write_table(spark, T.gold_payment_summary(payments), "gold", "payment_type_summary")
        for t in ["fact_order_lines", "daily_sales", "top_categories", "delivery_performance", "customer_rfm",
                  "order_status_mix", "payment_type_summary"]:
            counts["gold"][t] = read_table(spark, "gold", t).count()

    # ---------------- Quality and reconciliation ----------------
    with stage("quality"):
        rules = quality_rules(counts["bronze"], quarantine)
        q_reasons = [r.asDict() for r in quarantine.groupBy("source_table", "reason").agg(F.count("*").alias("rows"))
                     .orderBy("source_table", "reason").collect()]
        rec = reconcile(read_table(spark, "bronze", "order_items"), quarantine, items, orders, daily)

    total = round(time.perf_counter() - t_start, 2)
    metrics = {"mode": mode, "batch_id": batch, "finished_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
               "spark_version": spark.version, "stage_seconds": stages, "total_seconds": total, "counts": counts,
               "quarantine_by_reason": q_reasons, "quality_rules": rules, "reconciliation": rec}
    out = ROOT / "outputs"
    (out / "run_metrics.json").write_text(json.dumps(metrics, indent=2, default=str))
    hist = out / "run_history.json"
    h = json.loads(hist.read_text()) if hist.exists() else []
    h.append(metrics)
    hist.write_text(json.dumps(h, indent=2, default=str))
    print(json.dumps({k: metrics[k] for k in ["mode", "total_seconds", "stage_seconds", "counts", "reconciliation"]}, indent=2, default=str))
    spark.stop()


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--mode", choices=["full", "incremental"], default="full")
    a = ap.parse_args()
    run(a.mode)
