"""
export_gold_to_csv.py
Copies the Gold tables to CSV so the dashboard can read them without Spark or Snowflake.
Small tables go to dashboard/data (committed to Git, used by Streamlit Cloud).
customer_rfm has ~89k rows, so the dashboard gets a segment summary and the full file goes to outputs/gold_csv.
"""
from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
GOLD = ROOT / "outputs" / "lakehouse" / "gold"
DASH = ROOT / "dashboard" / "data"
FULL = ROOT / "outputs" / "gold_csv"
DASH.mkdir(parents=True, exist_ok=True)
FULL.mkdir(parents=True, exist_ok=True)

for name in ["daily_sales", "top_categories", "delivery_performance", "order_status_mix", "payment_type_summary"]:
    df = pd.read_parquet(GOLD / name)
    df.to_csv(DASH / f"{name}.csv", index=False)
    print(name, len(df))

rfm = pd.read_parquet(GOLD / "customer_rfm")
rfm.to_csv(FULL / "customer_rfm.csv", index=False)
rfm["monetary"] = rfm["monetary"].astype(float)
seg = (rfm.groupby("segment").agg(customers=("customer_unique_id", "count"), revenue=("monetary", "sum"),
                                  avg_orders=("frequency", "mean"), avg_recency_days=("recency_days", "mean")).round(2).reset_index())
seg.to_csv(DASH / "rfm_segment_summary.csv", index=False)
print("rfm_segment_summary", len(seg), "| customer_rfm", len(rfm))
