"""Builds the three diagrams used in the report and README (Graphviz, PNG at 220 dpi)."""
import subprocess
from pathlib import Path

OUT = Path(__file__).resolve().parent
BLUE, TEAL, GOLD, GREY, RED, GREEN = "#0b5c8f", "#1a8a8a", "#c48a10", "#5a6672", "#b3372f", "#2b8a4b"
FONT = 'fontname="Helvetica"'


def render(name, dot):
    src = OUT / f"{name}.dot"
    src.write_text(dot)
    subprocess.run(["dot", "-Tpng", "-Gdpi=220", str(src), "-o", str(OUT / f"{name}.png")], check=True)
    src.unlink()


def box(title, lines, color, width=2.4):
    body = "".join(f'<TR><TD ALIGN="LEFT"><FONT POINT-SIZE="10" COLOR="#26313a">{l}</FONT></TD></TR>' for l in lines)
    return (f'<<TABLE BORDER="0" CELLBORDER="0" CELLSPACING="0" CELLPADDING="4">'
            f'<TR><TD BGCOLOR="{color}" ALIGN="LEFT"><FONT COLOR="white" POINT-SIZE="12"><B> {title} </B></FONT></TD></TR>{body}</TABLE>>')


arch = f'''digraph G {{
 rankdir=TB; splines=spline; nodesep=0.55; ranksep=0.65; bgcolor="white"; pad=0.3; newrank=true;
 node [shape=box, style="rounded,filled", fillcolor="#f6f8fa", color="#c9d1d9", penwidth=1.3, {FONT}];
 edge [color="{GREY}", penwidth=1.5, arrowsize=0.8, {FONT}, fontsize=10, fontcolor="{GREY}"];
 src [label={box("Source files", ["6 CSVs shaped like Olist (orders, order_items, customers,", "products, payments, reviews) + one incremental batch", "generated with seed 42"], GREY)}];
 subgraph cluster_db {{ label="Databricks  (PySpark + Delta Lake)"; labeljust=l; fontsize=14; {FONT}; fontcolor="{BLUE}"; color="{BLUE}"; style="rounded,dashed"; penwidth=1.6;
  br [label={box("Bronze", ["Raw text as received", "+ source file, batch id, row id", "Full: overwrite", "Incremental: insert new rows"], "#8c6d2f")}];
  sv [label={box("Silver", ["Typed, standardised, de-duplicated", "Rules split good and bad rows", "Full: overwrite", "Incremental: MERGE on key"], BLUE)}];
  gd [label={box("Gold", ["daily_sales, top_categories", "delivery_performance, customer_rfm", "order_status_mix, payment_type_summary", "fact_order_lines"], GOLD)}];
  q  [label={box("Quarantine", ["Failed rows + reason", "+ raw record as JSON"], RED)}];
  {{rank=same; br; sv; gd}}
 }}
 ld [label={box("Loader (notebook 04)", ["Spark-Snowflake connector", "Credentials from a Databricks secret scope"], TEAL)}];
 subgraph cluster_sf {{ label="Snowflake  (RETAIL_DB, X-Small warehouse, auto-suspend 60 s)"; labeljust=l; fontsize=14; {FONT}; fontcolor="{TEAL}"; color="{TEAL}"; style="rounded,dashed"; penwidth=1.6;
  raw [label={box("RAW", ["ORDER_LINES_LANDING (append only)", "QUARANTINE"], TEAL)}];
  cur [label={box("CURATED", ["ORDER_LINES", "one row per order line"], TEAL)}];
  an  [label={box("ANALYTICS", ["DAILY_SALES + 5 more tables", "ANALYST_ROLE: read only"], TEAL)}];
  {{rank=same; raw; cur; an}}
 }}
 ui [label={box("Consumers", ["Snowsight SQL (10 queries)  |  Static dashboard on Netlify  |  Streamlit dashboard"], GREEN)}];
 src -> br; br -> sv; sv -> gd; sv -> q [color="{RED}", style=dashed, label=" bad rows"];
 gd -> ld; ld -> raw [label=" append order lines"]; ld -> an [label=" replace Gold tables"];
 raw -> cur [label="Stream 1 + Task 1\\nMERGE"]; cur -> an [label="Stream 2 + Task 2\\nMERGE"];
 an -> ui; gd -> ui [style=dashed, label=" Gold CSV export"];
}}'''
render("architecture", arch)


def table(name, color, cols):
    rows = "".join(f'<TR><TD ALIGN="LEFT" PORT="{c.split()[0]}"><FONT POINT-SIZE="9" COLOR="#26313a">{c}</FONT></TD></TR>' for c in cols)
    return (f'<<TABLE BORDER="1" COLOR="#c9d1d9" CELLBORDER="0" CELLSPACING="0" CELLPADDING="3">'
            f'<TR><TD BGCOLOR="{color}"><FONT COLOR="white" POINT-SIZE="11"><B>{name}</B></FONT></TD></TR>{rows}</TABLE>>')


er = f'''digraph G {{
 rankdir=LR; nodesep=0.35; ranksep=0.9; bgcolor="white"; pad=0.3; splines=true;
 node [shape=plain, {FONT}]; edge [color="{GREY}", {FONT}, fontsize=9, fontcolor="{GREY}", arrowsize=0.7];
 subgraph cluster_s {{ label="Silver"; fontsize=14; {FONT}; color="{BLUE}"; style="rounded,dashed"; fontcolor="{BLUE}";
  customers [label={table("customers", BLUE, ["PK customer_id", "customer_unique_id", "zip_prefix", "city, state"])}];
  orders [label={table("orders", BLUE, ["PK order_id", "FK customer_id", "order_status", "purchase_ts, approved_ts", "carrier_ts, delivered_ts", "estimated_ts"])}];
  items [label={table("order_items", BLUE, ["PK order_id + order_item_id", "FK order_id", "FK product_id", "seller_id", "price, freight_value"])}];
  products [label={table("products", BLUE, ["PK product_id", "category", "weight_g"])}];
  payments [label={table("payments", BLUE, ["PK order_id + payment_sequential", "FK order_id", "payment_type", "installments", "payment_value"])}];
  reviews [label={table("reviews", BLUE, ["PK review_id", "FK order_id", "review_score", "review_created_ts"])}];
  quar [label={table("quarantine", RED, ["source_table", "reason", "record_key", "raw_record (JSON)", "_row_id, _batch_id"])}];
 }}
 subgraph cluster_g {{ label="Gold"; fontsize=14; {FONT}; color="{GOLD}"; style="rounded,dashed"; fontcolor="{GOLD}";
  fact [label={table("fact_order_lines", GOLD, ["order_id + order_item_id", "order_date, order_month", "customer_unique_id, state", "category, price, freight", "one row per order line"])}];
  daily [label={table("daily_sales", GOLD, ["order_date (grain)", "orders, items_sold", "revenue, freight_value", "avg_order_value"])}];
  cats [label={table("top_categories", GOLD, ["order_month + category (grain)", "orders, items_sold, revenue", "rank_in_month"])}];
  deliv [label={table("delivery_performance", GOLD, ["customer_state + order_month", "delivered_orders", "avg_delivery_days, avg_delay_days", "late_orders, late_pct", "avg_review_score"])}];
  rfm [label={table("customer_rfm", GOLD, ["customer_unique_id (grain)", "recency_days, frequency, monetary", "r_score, f_score, m_score", "segment"])}];
 }}
 customers -> orders [label="1 : N"]; orders -> items [label="1 : N"]; products -> items [label="1 : N"];
 orders -> payments [label="1 : N"]; orders -> reviews [label="1 : 0..N"];
 items -> fact [style=dashed, color="{GOLD}"]; orders -> fact [style=dashed, color="{GOLD}"]; customers -> fact [style=dashed, color="{GOLD}"]; products -> fact [style=dashed, color="{GOLD}"];
 fact -> daily [style=dashed, color="{GOLD}"]; fact -> cats [style=dashed, color="{GOLD}"]; fact -> rfm [style=dashed, color="{GOLD}"];
 orders -> deliv [style=dashed, color="{GOLD}"]; reviews -> deliv [style=dashed, color="{GOLD}"];
}}'''
render("er_diagram", er)


def make_flow():
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.patches import FancyBboxPatch, Polygon, FancyArrowPatch
    fig, ax = plt.subplots(figsize=(11, 6.6), dpi=220)
    ax.set_xlim(0, 11); ax.set_ylim(0, 6.6); ax.axis("off")
    W, H = 2.25, 1.0
    xs = [0.15, 2.95, 5.75, 8.55]
    ys = [5.2, 3.0, 0.8]

    def proc(x, y, title, sub, fc="#eef4fa", ec=BLUE):
        ax.add_patch(FancyBboxPatch((x, y), W, H, boxstyle="round,pad=0.02,rounding_size=0.12", fc=fc, ec=ec, lw=1.6))
        ax.text(x + W / 2, y + H * 0.66, title, ha="center", va="center", fontsize=9.5, fontweight="bold", color="#1d2730")
        ax.text(x + W / 2, y + H * 0.3, sub, ha="center", va="center", fontsize=7.6, color="#3b4650", linespacing=1.25)

    def cp(x, y, title, sub, cloud=False):
        cx, cy, w, h = x + W / 2, y + H / 2, W / 2, H / 2 + 0.05
        ax.add_patch(Polygon([(cx - w, cy), (cx - w * 0.72, cy + h), (cx + w * 0.72, cy + h), (cx + w, cy), (cx + w * 0.72, cy - h), (cx - w * 0.72, cy - h)],
                             closed=True, fc="#fff4d6", ec=GOLD, lw=1.6, ls="--" if cloud else "-"))
        ax.text(cx, cy + 0.2, title, ha="center", va="center", fontsize=9, fontweight="bold", color="#6b4b00")
        ax.text(cx, cy - 0.14, sub, ha="center", va="center", fontsize=7.4, color="#3b4650", linespacing=1.25)

    def arrow(p1, p2, color=GREY, ls="-", rad=0.0, label=None):
        ax.add_patch(FancyArrowPatch(p1, p2, arrowstyle="-|>", mutation_scale=13, color=color, lw=1.5, ls=ls, connectionstyle=f"arc3,rad={rad}"))
        if label:
            ax.text((p1[0] + p2[0]) / 2, (p1[1] + p2[1]) / 2 + 0.1, label, fontsize=7.2, color=color, ha="center")

    r1, r2, r3 = ys
    proc(xs[0], r1, "Source CSVs", "6 files + one\nincremental batch", "#f0f2f4", GREY)
    proc(xs[1], r1, "Bronze ingest", "all columns as text,\nadd lineage + _row_id")
    cp(xs[2], r1, "CP1", "Bronze rows =\nsource rows")
    proc(xs[3], r1, "Silver cleaning", "null keys, timestamps, dates,\namounts, score, dupes, orphans")
    # row 2 flows right to left
    cp(xs[3], r2, "CP2", "Bronze = Silver +\nQuarantine")
    proc(xs[2], r2, "Gold aggregates", "7 tables rebuilt\nfrom Silver")
    cp(xs[1], r2, "CP3", "Revenue waterfall\nsource = Gold + excluded")
    proc(xs[0], r2, "Load to Snowflake", "landing append,\nGold tables replaced", "#e3f3f3", TEAL)
    # row 3 left to right
    cp(xs[0], r3, "CP4  (Snowflake)", "Row counts equal\nin both systems", cloud=True)
    proc(xs[1], r3, "Stream + Task", "MERGE into CURATED,\nthen DAILY_SALES", "#e3f3f3", TEAL)
    cp(xs[2], r3, "CP5  (Snowflake)", "Task history\nstate = SUCCEEDED", cloud=True)
    proc(xs[3], r3, "Dashboard + SQL", "static site, Streamlit,\nSnowsight queries", "#e6f4ea", GREEN)
    m = W / 2
    for i in range(3):
        arrow((xs[i] + W, r1 + H / 2), (xs[i + 1], r1 + H / 2))
    arrow((xs[3] + m, r1), (xs[3] + m, r2 + H))
    for i in (3, 2, 1):
        arrow((xs[i], r2 + H / 2), (xs[i - 1] + W, r2 + H / 2))
    arrow((xs[0] + m, r2), (xs[0] + m, r3 + H))
    for i in range(3):
        arrow((xs[i] + W, r3 + H / 2), (xs[i + 1], r3 + H / 2))
    ax.text(xs[3] + m + 0.08, (r1 + r2 + H) / 2 - 0.02, "good rows;  bad rows go to\nthe quarantine table", fontsize=7.4, color=RED, va="center")
    ax.text(xs[0] + m + 0.08, (r2 + r3 + H) / 2, "cloud step", fontsize=7.4, color=GREY, va="center")
    ax.text(5.5, 0.12, "CP1 to CP3 are asserted by notebook 05 on Databricks (a failure stops the job before the Snowflake load) and by tests/test_pipeline.py locally.\nDashed hexagons run only in the cloud.",
            ha="center", fontsize=8, color=GREY)
    fig.savefig(OUT / "pipeline_flow.png", bbox_inches="tight", pad_inches=0.15)


make_flow()
print("diagrams done")
