"""
make_figures.py
Draws every chart and every "terminal output" image used in the report. Everything is read from the Gold Parquet
tables and from outputs/*.json, so the figures always match the last run. Output: docs/figures/*.png
"""
import json
import textwrap
from decimal import Decimal
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.ticker as mt
import pandas as pd
from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parents[1]
GOLD = ROOT / "outputs" / "lakehouse" / "gold"
OUT = ROOT / "docs" / "figures"
OUT.mkdir(parents=True, exist_ok=True)
M = json.loads((ROOT / "outputs" / "run_metrics.json").read_text())
HIST = json.loads((ROOT / "outputs" / "run_history.json").read_text())
TESTS = json.loads((ROOT / "outputs" / "test_results.json").read_text())

BLUE, TEAL, GOLDC, RED, GREEN, PURPLE, GREY = "#0b5c8f", "#1a8a8a", "#c48a10", "#b3372f", "#2b8a4b", "#6f5aa8", "#5a6672"
plt.rcParams.update({"font.family": "Carlito", "font.size": 11, "axes.spines.top": False, "axes.spines.right": False,
                     "axes.edgecolor": "#9aa7b3", "axes.labelcolor": "#26313a", "axes.titleweight": "bold", "axes.titlesize": 13,
                     "xtick.color": "#3b4650", "ytick.color": "#3b4650", "axes.grid": True, "grid.color": "#e6ebef", "grid.linewidth": 0.8,
                     "axes.axisbelow": True, "figure.dpi": 100})


def tab(name):
    df = pd.read_parquet(GOLD / name)
    for c in df.columns:
        if df[c].dtype == object and len(df) and isinstance(df[c].iloc[0], Decimal):
            df[c] = df[c].astype(float)
    return df


def save(fig, name):
    fig.savefig(OUT / name, dpi=200, bbox_inches="tight", facecolor="white")
    plt.close(fig)


money = mt.FuncFormatter(lambda v, _: f"R$ {v/1e6:.1f}M" if v >= 1e6 else f"R$ {v/1e3:.0f}K")
daily, cats, deliv, rfm = tab("daily_sales"), tab("top_categories"), tab("delivery_performance"), tab("customer_rfm")
status, pay = tab("order_status_mix"), tab("payment_type_summary")

# 1 monthly revenue
m = daily.assign(m=pd.to_datetime(daily.order_date).dt.to_period("M").dt.to_timestamp()).groupby("m").revenue.sum()
fig, ax = plt.subplots(figsize=(8, 3.9))
ax.plot(m.index, m.values, color=BLUE, lw=2.4, marker="o", ms=4)
ax.fill_between(m.index, m.values, color=BLUE, alpha=0.12)
peak = m.idxmax(); nov = pd.Timestamp("2017-11-01")
ax.annotate(f"Nov 2017\nR$ {m[nov]/1e3:.0f}K", (nov, m[nov]), xytext=(-70, 8), textcoords="offset points", fontsize=9.5, color=GREY, arrowprops=dict(arrowstyle="-", color=GREY))
ax.yaxis.set_major_formatter(money); ax.set_xlabel("Order month"); ax.set_ylabel("Revenue (item price)"); ax.set_title("Monthly revenue")
save(fig, "chart_monthly_revenue.png")

# 2 top categories
t = cats.groupby("category").revenue.sum().sort_values().tail(10)
fig, ax = plt.subplots(figsize=(8, 4.3))
ax.barh([c.replace("_", " ") for c in t.index], t.values, color=TEAL)
for i, v in enumerate(t.values): ax.text(v, i, f"  R$ {v/1e6:.2f}M", va="center", fontsize=9.5, color="#26313a")
ax.xaxis.set_major_formatter(money); ax.set_xlabel("Revenue over the whole period"); ax.set_title("Top 10 categories by revenue"); ax.set_xlim(0, t.max() * 1.18); ax.grid(axis="y", visible=False)
save(fig, "chart_top_categories.png")

# 3 delivery by state
s = deliv.assign(w=deliv.avg_delay_days * deliv.delivered_orders, wd=deliv.avg_delivery_days * deliv.delivered_orders).groupby("customer_state").agg(
    o=("delivered_orders", "sum"), l=("late_orders", "sum"), w=("w", "sum"), wd=("wd", "sum"))
s["late_pct"], s["delay"], s["days"] = 100 * s.l / s.o, s.w / s.o, s.wd / s.o
s = s[s.o >= 500].sort_values("delay", ascending=False).head(12).iloc[::-1]
fig, ax = plt.subplots(figsize=(8, 4.4))
cols = [RED if v > 0 else GREEN for v in s.delay]
ax.barh(s.index, s.delay, color=cols)
for i, (v, lp) in enumerate(zip(s.delay, s.late_pct)): ax.text(v + (0.15 if v >= 0 else -0.15), i, f"{v:+.1f} d  |  {lp:.1f}% late", va="center", ha="left" if v >= 0 else "right", fontsize=9)
ax.axvline(0, color="#26313a", lw=1); ax.set_xlabel("Average days after (+) or before (-) the promised delivery date"); ax.set_ylabel("Customer state")
ax.set_title("Delivery delay by state (12 worst, states with 500+ deliveries)"); ax.grid(axis="y", visible=False); ax.set_xlim(s.delay.min() - 3, s.delay.max() + 5)
save(fig, "chart_delivery_delay_state.png")

# 4 rfm
r = rfm.groupby("segment").agg(customers=("customer_unique_id", "count"), revenue=("monetary", "sum")).sort_values("customers")
fig, ax = plt.subplots(figsize=(8, 3.7))
ax.barh(r.index, r.customers, color=[PURPLE, GOLDC, BLUE, TEAL, GREEN, RED][: len(r)])
for i, (n, rv) in enumerate(zip(r.customers, r.revenue)): ax.text(n, i, f"  {n:,} customers | R$ {rv/1e6:.2f}M", va="center", fontsize=9.5)
ax.set_xlabel("Customers"); ax.set_title("Customer segments (RFM)"); ax.set_xlim(0, r.customers.max() * 1.45); ax.grid(axis="y", visible=False)
save(fig, "chart_rfm_segments.png")

# 5 order status
st = status.sort_values("orders")
fig, ax = plt.subplots(figsize=(8, 3.7))
ax.barh(st.order_status, st.orders, color=BLUE)
ax.set_xscale("log")
for i, (n, p) in enumerate(zip(st.orders, st.pct)): ax.text(n * 1.08, i, f"{n:,}  ({p:.2f}%)", va="center", fontsize=9.5)
ax.set_xlabel("Orders (log scale, because 'delivered' is 97% of all orders)"); ax.set_title("Order status mix"); ax.set_xlim(1, st.orders.max() * 12); ax.grid(axis="y", visible=False)
save(fig, "chart_order_status.png")

# 6 payment types
p = pay.sort_values("total_value", ascending=False)
fig, axs = plt.subplots(1, 2, figsize=(8, 3.6), gridspec_kw={"width_ratios": [1, 1.2]})
axs[0].pie(p.total_value, labels=[t.replace("_", " ") for t in p.payment_type], colors=[BLUE, TEAL, GOLDC, PURPLE], autopct="%1.1f%%", startangle=90,
           wedgeprops=dict(width=0.42, edgecolor="white"), textprops={"fontsize": 9.5}, pctdistance=0.79)
axs[0].set_title("Share of payment value")
axs[1].bar([t.replace("_", " ") for t in p.payment_type], p.avg_installments, color=[BLUE, TEAL, GOLDC, PURPLE])
for i, v in enumerate(p.avg_installments): axs[1].text(i, v, f"{v:.1f}", ha="center", va="bottom", fontsize=9.5)
axs[1].set_ylabel("Average installments"); axs[1].set_title("Installments by payment type"); axs[1].tick_params(axis="x", labelsize=9)
fig.suptitle("Payment types", fontweight="bold", fontsize=13, y=1.02)
save(fig, "chart_payment_types.png")

# 7 quarantine by reason
q = pd.DataFrame(M["quarantine_by_reason"]); q["label"] = q.source_table + " / " + q.reason
q = q.sort_values("rows")
fig, ax = plt.subplots(figsize=(8, 4.6))
colmap = {"ORPHAN_ORDER": GOLDC, "DUPLICATE_KEY": BLUE, "NULL_KEY": RED}
ax.barh(q.label, q.rows, color=[colmap.get(r, TEAL) for r in q.reason])
for i, n in enumerate(q.rows): ax.text(n, i, f"  {n:,}", va="center", fontsize=9)
ax.set_xlabel("Rows sent to the quarantine table"); ax.set_title("Quarantined rows by table and reason"); ax.set_xlim(0, q.rows.max() * 1.12); ax.grid(axis="y", visible=False)
save(fig, "chart_quarantine_reasons.png")


# ---------------- terminal style images ----------------
MONO = "/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf"
MONOB = "/usr/share/fonts/truetype/dejavu/DejaVuSansMono-Bold.ttf"


def terminal(name, title, lines, width_chars=None, fs=17):
    f, fb = ImageFont.truetype(MONO, fs), ImageFont.truetype(MONOB, fs)
    w = max(len(l) for l in lines)
    cw = f.getlength("M")
    pad, bar, lh = 26, 40, int(fs * 1.5)
    W, H = int(w * cw + pad * 2), bar + pad + lh * len(lines) + pad
    im = Image.new("RGB", (W, H), "#101820")
    d = ImageDraw.Draw(im)
    d.rectangle([0, 0, W, bar], fill="#1d2a36")
    for i, c in enumerate(["#ff5f56", "#ffbd2e", "#27c93f"]): d.ellipse([16 + i * 22, 13, 28 + i * 22, 25], fill=c)
    d.text((100, 9), title, font=ImageFont.truetype(MONO, 15), fill="#9fb0bf")
    y = bar + pad
    for l in lines:
        color = "#d6dee6"
        if l.startswith(("PASS", "OK ")) or "PASS" in l[:6]: color = "#7ee787"
        if l.startswith("FAIL"): color = "#ff7b72"
        if l.startswith(("#", "$")): color = "#79c0ff"
        if set(l.strip()) <= set("-=+| "): color = "#5b6b7a"
        d.text((pad, y), l, font=f, fill=color)
        y += lh
    im.save(OUT / name)


def grid(headers, rows, aligns=None):
    cols = list(zip(*([headers] + rows)))
    widths = [max(len(str(x)) for x in c) for c in cols]
    aligns = aligns or ["<"] * len(headers)
    fmt = lambda r: "  ".join(f"{str(x):{a}{w}}" for x, w, a in zip(r, widths, aligns))
    return [fmt(headers), "  ".join("-" * w for w in widths)] + [fmt(r) for r in rows]


full = [h for h in HIST if h["mode"] == "full"][-1]
last = HIST[-1]
c = last["counts"]
lines = ["$ python local_run/run_pipeline_local.py --mode full   (then --mode incremental)", ""]
rows = [[t, f"{full['counts']['bronze'][t]:,}", f"{full['counts']['silver'][t]:,}", f"{c['bronze'][t]:,}", f"{c['silver'][t]:,}"] for t in ["orders", "order_items", "customers", "products", "payments", "reviews"]]
rows.append(["quarantine", "", f"{full['counts']['silver']['quarantine']:,}", "", f"{c['silver']['quarantine']:,}"])
lines += grid(["table", "bronze (full)", "silver (full)", "bronze (+inc)", "silver (+inc)"], rows, ["<", ">", ">", ">", ">"])
lines += ["", "gold tables after the incremental load:"] + [f"  {k:<22}{v:>9,} rows" for k, v in c["gold"].items()]
terminal("out_row_counts.png", "row counts per layer - local run", lines)

qr = full["quality_rules"]
lines = ["# data quality rules, full load (rows checked = Bronze rows of that table)", ""]
lines += grid(["rule", "checked", "failed", "pass rate"], [[r["rule"], f"{r['checked']:,}", f"{r['failed']:,}", f"{r['pass_rate']:.2f}%"] for r in qr], ["<", ">", ">", ">"])
terminal("out_quality_rules.png", "data quality results - local run", lines, fs=15)

lines = ["$ python tests/test_pipeline.py", ""]
for r in TESTS:
    lines.append(f"{r['status']:<5}{r['id']}  {textwrap.shorten(r['check'], 84, placeholder='...')}")
lines += ["", f"{sum(r['status']=='PASS' for r in TESTS)} of {len(TESTS)} passed"]
terminal("out_test_results.png", "test results - local run", lines, fs=16)

lines = ["# pipeline run history (local Parquet run log, the equivalent of DESCRIBE HISTORY on Delta)", ""]
rows = [[i + 1, h["mode"], h["finished_utc"][11:19], f"{h['total_seconds']:.1f}", f"{h['counts']['bronze']['orders']:,}", f"{h['counts']['silver']['orders']:,}",
         f"{h['counts']['silver']['quarantine']:,}", f"{h['counts']['gold']['daily_sales']:,}"] for i, h in enumerate(HIST)]
lines += grid(["run", "mode", "utc", "seconds", "bronze orders", "silver orders", "quarantine", "daily_sales rows"], rows, [">", "<", "<", ">", ">", ">", ">", ">"])
terminal("out_run_history.png", "run history - local run", lines, fs=15)

r = last["reconciliation"]
lines = ["# revenue waterfall, item price (BRL), after full + incremental load", "",
         f"source files (all item rows)             {Decimal(r['source_raw_revenue']):>15,.2f}"]
for k, v in sorted(r["quarantined_by_reason"].items()): lines.append(f"  - quarantined {k:<22}{Decimal(v):>15,.2f}")
lines += [f"  = Silver order_items                   {Decimal(r['silver_revenue']):>15,.2f}",
          f"  - cancelled / unavailable orders       {Decimal(r['excluded_canceled_unavailable']):>15,.2f}",
          f"  = Gold daily_sales revenue             {Decimal(r['gold_revenue']):>15,.2f}", "",
          f"source = quarantined + silver : {r['source_equals_quarantine_plus_silver']}", f"silver = gold + excluded      : {r['silver_equals_gold_plus_excluded']}"]
terminal("out_reconciliation.png", "revenue reconciliation - local run", lines, fs=16)

stg = last["stage_seconds"]
lines = ["# stage timings, seconds (1 CPU core, 4 GB RAM sandbox)", ""]
rows = [[i + 1, h["mode"]] + [f"{h['stage_seconds'][k]:.1f}" for k in ["bronze", "silver", "gold", "quality"]] + [f"{h['total_seconds']:.1f}"] for i, h in enumerate(HIST)]
lines += grid(["run", "mode", "bronze", "silver", "gold", "quality", "total"], rows, [">", "<", ">", ">", ">", ">", ">"])
terminal("out_timings.png", "stage timings - local run", lines, fs=16)
print("figures:", sorted(p.name for p in OUT.glob("*.png")))
