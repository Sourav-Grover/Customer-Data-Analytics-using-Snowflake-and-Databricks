# Demo video script (2–3 minutes)

**0:00–0:15 — Intro**
"This is a customer data analytics pipeline built on Databricks and Snowflake. It cleans
and analyses e-commerce order data using a medallion architecture — Bronze, Silver, Gold
— and serves the results through Snowflake and two dashboards."

**0:15–0:45 — Architecture**
Show `diagrams/architecture.png` (or Figure 6.1 in the report). Walk through: source
CSVs → Bronze (raw) → Silver (cleaned, validated, quarantine table for bad rows) → Gold
(7 aggregate tables) → loaded into Snowflake → a stream and two chained tasks keep it
refreshed incrementally → two dashboards read the same Gold data.

**0:45–1:15 — Run it live**
Terminal: `python local_run/run_pipeline_local.py --mode full`. While it runs, narrate:
"This is running the exact same cleaning and aggregation logic that runs on Databricks,
on my laptop, against 100,000+ synthetic orders." Show the final JSON summary (row
counts, reconciliation).

**1:15–1:40 — Data quality and tests**
Show `outputs/test_results.json` or Figure 9.6 (16 of 16 tests passing). Mention: "One
of these is an independent recalculation of total revenue in plain pandas, checked
against the Spark output — it has to match to the cent."

**1:40–2:10 — Dashboards**
Screen-record the Streamlit app: adjust the month-range slider, point out revenue,
late-delivery-by-state, and the RFM segments. Then open the static site link (the
deployed Netlify/Vercel URL) to show the same numbers with zero server.

**2:10–2:40 — Snowflake**
Screen-record Snowsight: run one query from `04_analysis_queries.sql`, then run
`05_security_tests.sql` as `ANALYST_ROLE` to show the permission failures are real
(INSERT/DELETE/DROP all rejected).

**2:40–3:00 — Close**
"All the code, the tests, the SQL and the report are in the GitHub repo linked below.
Thanks for watching."
