"""
build_static_site.py
Reads the Gold CSVs in dashboard/data and writes site/index.html: one self-contained page with the data embedded.
There is no server, no build step and no external script, so it can be dropped on Netlify, Vercel or GitHub Pages as is.

    python dashboard/build_static_site.py
"""
import json
from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
D = ROOT / "dashboard" / "data"
SITE = ROOT / "site"
SITE.mkdir(exist_ok=True)

daily = pd.read_csv(D / "daily_sales.csv", parse_dates=["order_date"])
cats = pd.read_csv(D / "top_categories.csv")
deliv = pd.read_csv(D / "delivery_performance.csv")
status = pd.read_csv(D / "order_status_mix.csv")
pay = pd.read_csv(D / "payment_type_summary.csv")
rfm = pd.read_csv(D / "rfm_segment_summary.csv")
metrics = json.loads((ROOT / "outputs" / "run_metrics.json").read_text())

monthly = daily.assign(m=daily.order_date.dt.strftime("%Y-%m")).groupby("m").agg(revenue=("revenue", "sum"), orders=("orders", "sum")).reset_index()
by_state = deliv.groupby("customer_state").agg(o=("delivered_orders", "sum"), l=("late_orders", "sum")).reset_index()
by_state["late_pct"] = (100 * by_state.l / by_state.o).round(2)
delay = deliv.assign(w=deliv.avg_delay_days * deliv.delivered_orders).groupby("customer_state").agg(w=("w", "sum"), o=("delivered_orders", "sum")).reset_index()
by_state["avg_delay_days"] = (delay.set_index("customer_state").w / delay.set_index("customer_state").o).round(2).reindex(by_state.customer_state).values
by_state = by_state[by_state.o >= 500].sort_values("late_pct", ascending=False)
cats["m"] = cats.order_month.str[:7]
top_all = cats.groupby("category").revenue.sum().sort_values(ascending=False).head(10).round(2)

tot_rev, tot_orders = float(daily.revenue.sum()), int(daily.orders.sum())
late_pct = 100 * deliv.late_orders.sum() / deliv.delivered_orders.sum()
q = sum(r["rows"] for r in metrics["quarantine_by_reason"])
DATA = {
    "kpi": {"revenue": round(tot_rev, 2), "orders": tot_orders, "aov": round(tot_rev / tot_orders, 2), "late_pct": round(late_pct, 2),
            "customers": int(rfm.customers.sum()), "quarantined": int(q), "runtime": metrics["total_seconds"], "mode": metrics["mode"],
            "balanced": bool(metrics["reconciliation"]["silver_equals_gold_plus_excluded"] and metrics["reconciliation"]["source_equals_quarantine_plus_silver"])},
    "monthly": monthly.round(2).to_dict("records"),
    "top_all": [{"label": k, "value": float(v)} for k, v in top_all.items()],
    "cat_months": {m: g.sort_values("rank_in_month").head(5)[["category", "revenue"]].round(2).to_dict("records") for m, g in cats.groupby("m")},
    "late_state": by_state.head(12)[["customer_state", "late_pct", "avg_delay_days", "o"]].to_dict("records"),
    "rfm": rfm.round(2).to_dict("records"),
    "status": status.sort_values("orders", ascending=False).to_dict("records"),
    "pay": pay.assign(total_value=pay.total_value.round(2)).sort_values("total_value", ascending=False).to_dict("records"),
}

HTML = r"""<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Customer Data Analytics - Snowflake and Databricks</title>
<meta name="description" content="Dashboard of the Gold tables produced by a PySpark medallion pipeline. Synthetic Olist-shaped data.">
<style>
:root{--bg:#f4f6f8;--card:#fff;--ink:#1d2730;--mut:#5a6672;--line:#dde3e9;--c1:#0b5c8f;--c2:#1a8a8a;--c3:#c48a10;--c4:#b3372f;--c5:#2b8a4b;--c6:#6f5aa8}
@media(prefers-color-scheme:dark){:root{--bg:#10161c;--card:#18212a;--ink:#e6ebef;--mut:#9aa7b3;--line:#2a3541;--c1:#4aa3df;--c2:#3cc0c0;--c3:#e0a92e;--c4:#e0645c;--c5:#4fbf7a;--c6:#a08ee0}}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font:15px/1.45 "Segoe UI",Calibri,Arial,sans-serif}
header{background:var(--c1);color:#fff;padding:22px 20px}header h1{margin:0;font-size:22px}header p{margin:4px 0 0;opacity:.9;font-size:13.5px}
main{max-width:1120px;margin:0 auto;padding:18px 16px 40px}
.kpis{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px}
.card{background:var(--card);border:1px solid var(--line);border-radius:10px;padding:14px 16px}
.kpi b{display:block;font-size:22px;margin-top:2px}.kpi span{color:var(--mut);font-size:12px;text-transform:uppercase;letter-spacing:.05em}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(340px,1fr));gap:14px;margin-top:14px}
.wide{grid-column:1/-1}h2{font-size:15px;margin:0 0 2px}.sub{color:var(--mut);font-size:12.5px;margin:0 0 8px}
svg{width:100%;height:auto;display:block}svg text{fill:var(--mut);font-size:11px}svg .v{fill:var(--ink)}
select{background:var(--card);color:var(--ink);border:1px solid var(--line);border-radius:6px;padding:4px 8px;font:inherit}
.ok{color:var(--c5)}.note{color:var(--mut);font-size:12.5px;margin-top:18px}
</style></head><body>
<header><h1>Customer Data Analytics using Snowflake and Databricks</h1>
<p>Gold tables from a PySpark medallion pipeline. Data is synthetic and shaped like the Olist Brazilian E-Commerce dataset (generator seed 42), not the real Kaggle files.</p></header>
<main>
<section class="kpis" id="kpis"></section>
<section class="grid">
 <div class="card wide"><h2>Monthly revenue</h2><p class="sub">Sum of item price for orders that were not cancelled or unavailable (table: daily_sales)</p><div id="c_month"></div></div>
 <div class="card"><h2>Top 10 categories by revenue</h2><p class="sub">Whole period (table: top_categories)</p><div id="c_cat"></div></div>
 <div class="card"><h2>Best categories in <select id="mSel"></select></h2><p class="sub">Top 5 by revenue for the chosen month</p><div id="c_catm"></div></div>
 <div class="card"><h2>Late deliveries by state</h2><p class="sub">Share of delivered orders that arrived after the promised date (states with 500+ deliveries)</p><div id="c_late"></div></div>
 <div class="card"><h2>Customer segments (RFM)</h2><p class="sub">Customers per segment (table: customer_rfm)</p><div id="c_rfm"></div></div>
 <div class="card"><h2>Order status mix</h2><p class="sub">All valid orders in Silver (table: order_status_mix)</p><div id="c_status"></div></div>
 <div class="card"><h2>Payment types by value</h2><p class="sub">Share of total payment value (table: payment_type_summary)</p><div id="c_pay"></div></div>
</section>
<p class="note">Built by <code>dashboard/build_static_site.py</code> from the Gold tables. The same numbers are available in Snowflake through <code>snowflake/04_analysis_queries.sql</code>.</p>
</main>
<script>
const D=__DATA__;
const col=i=>getComputedStyle(document.documentElement).getPropertyValue('--c'+(i%6+1)).trim();
const money=v=>v>=1e6?'R$ '+(v/1e6).toFixed(2)+'M':v>=1e3?'R$ '+(v/1e3).toFixed(0)+'K':'R$ '+v.toFixed(0);
const num=v=>v.toLocaleString('en-US');
const svg=(w,h,inner)=>`<svg viewBox="0 0 ${w} ${h}" role="img">${inner}</svg>`;
function hbars(el,items,fmt,color){const W=520,r=26,H=items.length*r+8,L=150,mx=Math.max(...items.map(i=>i.value));
 el.innerHTML=svg(W,H,items.map((it,i)=>{const w=(W-L-70)*it.value/mx;return `<text x="${L-8}" y="${i*r+17}" text-anchor="end">${it.label}</text><rect x="${L}" y="${i*r+4}" width="${w}" height="17" rx="3" fill="${color||col(0)}"><title>${it.label}: ${fmt(it.value)}</title></rect><text class="v" x="${L+w+6}" y="${i*r+17}">${fmt(it.value)}</text>`}).join(''))}
function line(el,pts){const W=1040,H=300,L=64,B=30,T=12,R=16,mx=Math.max(...pts.map(p=>p.revenue)),x=i=>L+(W-L-R)*i/(pts.length-1),y=v=>T+(H-T-B)*(1-v/mx);
 let g='';for(let k=0;k<=4;k++){const v=mx*k/4;g+=`<line x1="${L}" x2="${W-R}" y1="${y(v)}" y2="${y(v)}" stroke="var(--line)"/><text x="${L-8}" y="${y(v)+4}" text-anchor="end">${money(v)}</text>`}
 pts.forEach((p,i)=>{if(i%3==0)g+=`<text x="${x(i)}" y="${H-8}" text-anchor="middle">${p.m}</text>`});
 const path=pts.map((p,i)=>(i?'L':'M')+x(i)+' '+y(p.revenue)).join(' ');
 g+=`<path d="${path} L${x(pts.length-1)} ${H-B} L${x(0)} ${H-B}Z" fill="${col(0)}" opacity=".12"/><path d="${path}" fill="none" stroke="${col(0)}" stroke-width="2.5"/>`;
 pts.forEach((p,i)=>g+=`<circle cx="${x(i)}" cy="${y(p.revenue)}" r="4" fill="${col(0)}"><title>${p.m}: ${money(p.revenue)}, ${num(p.orders)} orders</title></circle>`);
 el.innerHTML=svg(W,H,g)}
function donut(el,items,fmt){const W=520,H=210,cx=105,cy=105,R=90,r=54,tot=items.reduce((a,b)=>a+b.value,0);let a0=-Math.PI/2,g='';
 items.forEach((it,i)=>{const a1=a0+2*Math.PI*it.value/tot,big=a1-a0>Math.PI?1:0,p=(rad,a)=>[cx+rad*Math.cos(a),cy+rad*Math.sin(a)];
  const [x0,y0]=p(R,a0),[x1,y1]=p(R,a1),[x2,y2]=p(r,a1),[x3,y3]=p(r,a0);
  g+=`<path d="M${x0} ${y0}A${R} ${R} 0 ${big} 1 ${x1} ${y1}L${x2} ${y2}A${r} ${r} 0 ${big} 0 ${x3} ${y3}Z" fill="${col(i)}"><title>${it.label}: ${fmt(it.value)}</title></path>`;
  g+=`<rect x="230" y="${18+i*24}" width="12" height="12" rx="2" fill="${col(i)}"/><text class="v" x="250" y="${28+i*24}">${it.label}</text><text x="${W-8}" y="${28+i*24}" text-anchor="end">${(100*it.value/tot).toFixed(1)}%</text>`;a0=a1});
 el.innerHTML=svg(W,H,g)}
const K=D.kpi;
document.getElementById('kpis').innerHTML=[['Revenue',money(K.revenue)],['Orders',num(K.orders)],['Avg order value','R$ '+K.aov.toFixed(2)],['Late deliveries',K.late_pct+'%'],['Customers',num(K.customers)],['Rows quarantined',num(K.quarantined)],['Revenue reconciliation',K.balanced?'<span class="ok">balanced</span>':'CHECK'],['Pipeline run',K.runtime+' s ('+K.mode+')']]
 .map(([a,b])=>`<div class="card kpi"><span>${a}</span><b>${b}</b></div>`).join('');
line(document.getElementById('c_month'),D.monthly);
hbars(document.getElementById('c_cat'),D.top_all.map(d=>({label:d.label.replace(/_/g,' '),value:d.value})),money,col(0));
const sel=document.getElementById('mSel'),ms=Object.keys(D.cat_months);ms.forEach(m=>sel.add(new Option(m,m)));sel.value=ms[ms.length-2];
const drawM=()=>hbars(document.getElementById('c_catm'),D.cat_months[sel.value].map(d=>({label:d.category.replace(/_/g,' '),value:d.revenue})),money,col(1));sel.onchange=drawM;drawM();
hbars(document.getElementById('c_late'),D.late_state.map(d=>({label:d.customer_state,value:d.late_pct})),v=>v.toFixed(1)+'%',col(3));
hbars(document.getElementById('c_rfm'),D.rfm.sort((a,b)=>b.customers-a.customers).map(d=>({label:d.segment,value:d.customers})),num,col(5));
donut(document.getElementById('c_status'),D.status.map(d=>({label:d.order_status,value:d.orders})),num);
donut(document.getElementById('c_pay'),D.pay.map(d=>({label:d.payment_type.replace('_',' '),value:d.total_value})),money);
</script></body></html>"""

(SITE / "index.html").write_text(HTML.replace("__DATA__", json.dumps(DATA, separators=(",", ":"))), encoding="utf-8")
print("wrote", SITE / "index.html", round((SITE / "index.html").stat().st_size / 1024, 1), "KB")
