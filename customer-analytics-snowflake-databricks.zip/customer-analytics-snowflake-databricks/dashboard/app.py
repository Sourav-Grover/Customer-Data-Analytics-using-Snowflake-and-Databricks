"""
Streamlit dashboard for the Gold tables.

Two data modes, chosen with an environment variable (or a Streamlit secret):
  DATA_SOURCE=csv        (default) reads the small Gold CSVs in dashboard/data, works anywhere with no credentials
  DATA_SOURCE=snowflake  reads the ANALYTICS schema with ANALYST_ROLE. Needs: SNOWFLAKE_ACCOUNT, SNOWFLAKE_USER,
                         SNOWFLAKE_PASSWORD (and optionally SNOWFLAKE_WAREHOUSE) plus `pip install snowflake-connector-python`.
"""
import os
from pathlib import Path

import altair as alt
import pandas as pd
import streamlit as st

st.set_page_config(page_title="Customer Data Analytics", layout="wide")
DATA = Path(__file__).parent / "data"          # relative path, so the app also works on Streamlit Community Cloud
TABLES = ["daily_sales", "top_categories", "delivery_performance", "order_status_mix", "payment_type_summary", "rfm_segment_summary"]


def cfg(key, default=None):
    """Environment variable first, then Streamlit secrets (used on Streamlit Community Cloud)."""
    if key in os.environ:
        return os.environ[key]
    try:
        return st.secrets[key]
    except Exception:
        return default


@st.cache_data(show_spinner="Loading Gold tables...")
def load(source):
    if source == "snowflake":
        import snowflake.connector
        con = snowflake.connector.connect(
            account=cfg("SNOWFLAKE_ACCOUNT"), user=cfg("SNOWFLAKE_USER"), password=cfg("SNOWFLAKE_PASSWORD"),
            warehouse=cfg("SNOWFLAKE_WAREHOUSE", "RETAIL_WH"), role="ANALYST_ROLE", database="RETAIL_DB", schema="ANALYTICS")
        out = {}
        for t in TABLES:
            if t == "rfm_segment_summary":      # computed in SQL so the 89k-row table is not pulled into the app
                df = pd.read_sql("SELECT SEGMENT, COUNT(*) AS CUSTOMERS, SUM(MONETARY) AS REVENUE FROM CUSTOMER_RFM GROUP BY SEGMENT", con)
            else:
                df = pd.read_sql(f"SELECT * FROM {t.upper()}", con)
            df.columns = [c.lower() for c in df.columns]
            out[t] = df
        con.close()
        return out
    return {t: pd.read_csv(DATA / f"{t}.csv") for t in TABLES}


source = cfg("DATA_SOURCE", "csv").lower()
d = load(source)
daily = d["daily_sales"].assign(order_date=lambda x: pd.to_datetime(x.order_date))
daily["revenue"] = daily.revenue.astype(float)

st.title("Customer Data Analytics")
st.caption(f"Source: {'Snowflake ANALYTICS schema' if source == 'snowflake' else 'Gold CSV files in dashboard/data'}. "
           "The data is synthetic and shaped like the Olist dataset (seed 42).")

months = sorted(daily.order_date.dt.to_period("M").astype(str).unique())
lo, hi = st.sidebar.select_slider("Month range", options=months, value=(months[0], months[-1]))
sel = daily[(daily.order_date.dt.to_period("M").astype(str) >= lo) & (daily.order_date.dt.to_period("M").astype(str) <= hi)]

deliv = d["delivery_performance"].copy()
deliv["order_month"] = pd.to_datetime(deliv.order_month).dt.to_period("M").astype(str)
deliv = deliv[(deliv.order_month >= lo) & (deliv.order_month <= hi)]

c = st.columns(5)
c[0].metric("Revenue", f"R$ {sel.revenue.sum():,.0f}")
c[1].metric("Orders", f"{int(sel.orders.sum()):,}")
c[2].metric("Avg order value", f"R$ {sel.revenue.sum() / max(sel.orders.sum(), 1):,.2f}")
c[3].metric("Late deliveries", f"{100 * deliv.late_orders.sum() / max(deliv.delivered_orders.sum(), 1):.2f}%")
c[4].metric("Days shown", f"{sel.order_date.nunique():,}")

monthly = sel.assign(month=sel.order_date.dt.to_period("M").dt.to_timestamp()).groupby("month", as_index=False).agg(revenue=("revenue", "sum"))
st.subheader("Monthly revenue")
st.altair_chart(alt.Chart(monthly).mark_area(line=True, opacity=0.25, color="#0b5c8f").encode(
    x=alt.X("month:T", title="Month"), y=alt.Y("revenue:Q", title="Revenue (R$)"), tooltip=["month:T", alt.Tooltip("revenue:Q", format=",.0f")]),
    use_container_width=True)

left, right = st.columns(2)
cats = d["top_categories"].copy()
cats["order_month"] = pd.to_datetime(cats.order_month).dt.to_period("M").astype(str)
cats = cats[(cats.order_month >= lo) & (cats.order_month <= hi)]
top = cats.groupby("category", as_index=False).revenue.sum().sort_values("revenue", ascending=False).head(10)
left.subheader("Top 10 categories")
left.altair_chart(alt.Chart(top).mark_bar(color="#1a8a8a").encode(
    y=alt.Y("category:N", sort="-x", title=None), x=alt.X("revenue:Q", title="Revenue (R$)"), tooltip=["category", alt.Tooltip("revenue:Q", format=",.0f")]),
    use_container_width=True)

st_late = (deliv.groupby("customer_state", as_index=False).agg(o=("delivered_orders", "sum"), l=("late_orders", "sum")).query("o >= 300"))
st_late["late_pct"] = 100 * st_late.l / st_late.o
right.subheader("Late deliveries by state")
right.altair_chart(alt.Chart(st_late.sort_values("late_pct", ascending=False).head(12)).mark_bar(color="#b3372f").encode(
    y=alt.Y("customer_state:N", sort="-x", title=None), x=alt.X("late_pct:Q", title="Late (%)"), tooltip=["customer_state", alt.Tooltip("late_pct:Q", format=".2f")]),
    use_container_width=True)

a, b, c3 = st.columns(3)
rfm = d["rfm_segment_summary"]
a.subheader("RFM segments")
a.altair_chart(alt.Chart(rfm).mark_bar(color="#2b8a4b").encode(
    y=alt.Y("segment:N", sort="-x", title=None), x=alt.X("customers:Q", title="Customers")), use_container_width=True)
b.subheader("Order status mix")
b.altair_chart(alt.Chart(d["order_status_mix"]).mark_arc(innerRadius=50).encode(
    theta="orders:Q", color=alt.Color("order_status:N", title=None), tooltip=["order_status", "orders", "pct"]), use_container_width=True)
c3.subheader("Payment types by value")
c3.altair_chart(alt.Chart(d["payment_type_summary"]).mark_arc(innerRadius=50).encode(
    theta="total_value:Q", color=alt.Color("payment_type:N", title=None), tooltip=["payment_type", "payments", alt.Tooltip("total_value:Q", format=",.0f")]),
    use_container_width=True)
