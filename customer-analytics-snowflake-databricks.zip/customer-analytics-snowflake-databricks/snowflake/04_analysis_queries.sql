-- 04_analysis_queries.sql
-- Ten business questions answered from the ANALYTICS schema. Run as ANALYST_ROLE.

USE ROLE ANALYST_ROLE;
USE WAREHOUSE RETAIL_WH;
USE SCHEMA RETAIL_DB.ANALYTICS;

-- Q1. Headline numbers: how much did we sell overall?
SELECT SUM(REVENUE) AS total_revenue, SUM(ORDERS) AS total_orders, SUM(ITEMS_SOLD) AS items_sold,
       ROUND(SUM(REVENUE) / SUM(ORDERS), 2) AS avg_order_value
FROM DAILY_SALES;

-- Q2. Is revenue growing? Monthly revenue with growth against the previous month.
WITH m AS (
  SELECT DATE_TRUNC('month', ORDER_DATE) AS month, SUM(REVENUE) AS revenue, SUM(ORDERS) AS orders
  FROM DAILY_SALES GROUP BY 1)
SELECT month, revenue, orders,
       ROUND(100.0 * (revenue - LAG(revenue) OVER (ORDER BY month)) / LAG(revenue) OVER (ORDER BY month), 1) AS growth_pct
FROM m ORDER BY month;

-- Q3. Which five categories bring the most revenue over the whole period?
SELECT CATEGORY, SUM(REVENUE) AS revenue, SUM(ITEMS_SOLD) AS items_sold
FROM TOP_CATEGORIES GROUP BY CATEGORY ORDER BY revenue DESC LIMIT 5;

-- Q4. Does the best category change from month to month? (rank 1 in each month)
SELECT ORDER_MONTH, CATEGORY, REVENUE
FROM TOP_CATEGORIES WHERE RANK_IN_MONTH = 1 ORDER BY ORDER_MONTH;

-- Q5. Which seven days had the highest revenue? Useful for spotting campaign or holiday spikes.
SELECT ORDER_DATE, REVENUE, ORDERS FROM DAILY_SALES ORDER BY REVENUE DESC LIMIT 7;

-- Q6. Which states get the most late deliveries? States with fewer than 500 delivered orders are ignored
-- because a handful of orders would make the percentage meaningless. Weighted by orders, not an average of monthly averages.
SELECT CUSTOMER_STATE, SUM(DELIVERED_ORDERS) AS delivered_orders, SUM(LATE_ORDERS) AS late_orders,
       ROUND(100.0 * SUM(LATE_ORDERS) / SUM(DELIVERED_ORDERS), 2) AS late_pct
FROM DELIVERY_PERFORMANCE GROUP BY CUSTOMER_STATE
HAVING SUM(DELIVERED_ORDERS) >= 500 ORDER BY late_pct DESC LIMIT 10;

-- Q7. How many days after the promised date do deliveries arrive, by state? (negative = earlier than promised)
SELECT CUSTOMER_STATE,
       ROUND(SUM(AVG_DELAY_DAYS * DELIVERED_ORDERS) / SUM(DELIVERED_ORDERS), 2) AS avg_delay_days,
       ROUND(SUM(AVG_DELIVERY_DAYS * DELIVERED_ORDERS) / SUM(DELIVERED_ORDERS), 2) AS avg_delivery_days
FROM DELIVERY_PERFORMANCE GROUP BY CUSTOMER_STATE
HAVING SUM(DELIVERED_ORDERS) >= 500 ORDER BY avg_delay_days DESC LIMIT 10;

-- Q8. How big is each customer segment and how much revenue does it hold?
SELECT SEGMENT, COUNT(*) AS customers, SUM(MONETARY) AS revenue,
       ROUND(100.0 * SUM(MONETARY) / SUM(SUM(MONETARY)) OVER (), 2) AS revenue_share_pct
FROM CUSTOMER_RFM GROUP BY SEGMENT ORDER BY revenue DESC;

-- Q9. What share of orders ends in each status?
SELECT ORDER_STATUS, ORDERS, PCT FROM ORDER_STATUS_MIX ORDER BY ORDERS DESC;

-- Q10. How do customers pay, and how many installments do card payments use?
SELECT PAYMENT_TYPE, PAYMENTS, TOTAL_VALUE,
       ROUND(100.0 * TOTAL_VALUE / SUM(TOTAL_VALUE) OVER (), 2) AS value_share_pct, AVG_INSTALLMENTS
FROM PAYMENT_TYPE_SUMMARY ORDER BY TOTAL_VALUE DESC;
