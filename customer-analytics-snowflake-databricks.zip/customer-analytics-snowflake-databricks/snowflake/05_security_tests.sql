-- 05_security_tests.sql
-- Proves that ANALYST_ROLE can read but not change anything. Every statement marked EXPECTED FAIL
-- must return an "Insufficient privileges" or "does not exist or not authorized" error.

-- ---- as analyst ----
USE ROLE ANALYST_ROLE;
USE WAREHOUSE RETAIL_WH;

SELECT COUNT(*) FROM RETAIL_DB.ANALYTICS.DAILY_SALES;                    -- EXPECTED OK
SELECT COUNT(*) FROM RETAIL_DB.CURATED.ORDER_LINES;                      -- EXPECTED OK

DELETE FROM RETAIL_DB.ANALYTICS.DAILY_SALES WHERE ORDER_DATE = '2018-01-01';   -- EXPECTED FAIL: insufficient privileges
INSERT INTO RETAIL_DB.ANALYTICS.DAILY_SALES (ORDER_DATE, ORDERS) VALUES ('2030-01-01', 1);   -- EXPECTED FAIL
TRUNCATE TABLE RETAIL_DB.ANALYTICS.CUSTOMER_RFM;                         -- EXPECTED FAIL
DROP TABLE RETAIL_DB.ANALYTICS.TOP_CATEGORIES;                           -- EXPECTED FAIL
SELECT COUNT(*) FROM RETAIL_DB.RAW.QUARANTINE;                           -- EXPECTED FAIL: analysts cannot see RAW
ALTER WAREHOUSE RETAIL_WH SET WAREHOUSE_SIZE = 'LARGE';                  -- EXPECTED FAIL: no MODIFY on the warehouse
ALTER TASK RETAIL_DB.RAW.T_MERGE_ORDER_LINES SUSPEND;                    -- EXPECTED FAIL

-- ---- as engineer: the same object is reachable, which shows the failures above are permissions, not typos ----
USE ROLE ENGINEER_ROLE;
SELECT COUNT(*) FROM RETAIL_DB.RAW.QUARANTINE;                           -- EXPECTED OK

-- ---- what analyst may do ----
SHOW GRANTS TO ROLE ANALYST_ROLE;
SHOW WAREHOUSES LIKE 'RETAIL_WH';                                        -- size XSMALL, auto_suspend 60
