-- 01_setup_warehouse_roles.sql
-- Run once as ACCOUNTADMIN. Creates the compute, the database and the two roles.

USE ROLE ACCOUNTADMIN;

-- X-Small is the smallest size and is enough for ~113k order lines. Auto-suspend after 60 seconds
-- because idle warehouse time is what burns trial credits. INITIALLY_SUSPENDED avoids paying while creating it.
CREATE WAREHOUSE IF NOT EXISTS RETAIL_WH
  WAREHOUSE_SIZE = 'XSMALL'
  AUTO_SUSPEND = 60
  AUTO_RESUME = TRUE
  INITIALLY_SUSPENDED = TRUE
  COMMENT = 'Capstone warehouse: smallest size, suspends after 60 s';

-- Safety net: notify at 80% of a 5 credit quota and suspend the warehouse at 100%
CREATE OR REPLACE RESOURCE MONITOR RETAIL_MONITOR
  WITH CREDIT_QUOTA = 5
  TRIGGERS ON 80 PERCENT DO NOTIFY
           ON 100 PERCENT DO SUSPEND;
ALTER WAREHOUSE RETAIL_WH SET RESOURCE_MONITOR = RETAIL_MONITOR;

CREATE DATABASE IF NOT EXISTS RETAIL_DB;

CREATE ROLE IF NOT EXISTS ENGINEER_ROLE;   -- loads data, owns the stream and tasks
CREATE ROLE IF NOT EXISTS ANALYST_ROLE;    -- read only

GRANT ROLE ENGINEER_ROLE TO ROLE SYSADMIN;
GRANT ROLE ANALYST_ROLE  TO ROLE ENGINEER_ROLE;

-- give both roles to the user running this script so the tests in 05 can switch between them
SET me = CURRENT_USER();
GRANT ROLE ENGINEER_ROLE TO USER IDENTIFIER($me);
GRANT ROLE ANALYST_ROLE  TO USER IDENTIFIER($me);

GRANT USAGE, OPERATE ON WAREHOUSE RETAIL_WH TO ROLE ENGINEER_ROLE;
GRANT USAGE           ON WAREHOUSE RETAIL_WH TO ROLE ANALYST_ROLE;   -- no MODIFY: analysts cannot resize it
GRANT ALL ON DATABASE RETAIL_DB TO ROLE ENGINEER_ROLE;
GRANT EXECUTE TASK ON ACCOUNT TO ROLE ENGINEER_ROLE;                  -- needed to resume a task
GRANT USAGE ON DATABASE RETAIL_DB TO ROLE ANALYST_ROLE;
-- schema and table grants for ANALYST_ROLE are in 02_schemas_tables.sql, after the schemas exist

SHOW WAREHOUSES LIKE 'RETAIL_WH';
