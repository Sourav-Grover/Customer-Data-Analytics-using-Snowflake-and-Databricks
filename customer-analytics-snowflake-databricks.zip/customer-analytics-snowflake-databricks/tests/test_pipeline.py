"""
test_pipeline.py
Checks the outputs of local_run/run_pipeline_local.py against the raw files, the injection manifest and an
independent pandas re-calculation. Writes outputs/test_results.json, which the report reads.

    python tests/test_pipeline.py        (run after a full load and one incremental load)
"""
import json
import sys
import time
from decimal import Decimal
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
LAKE = ROOT / "outputs" / "lakehouse"
RAW, INC = ROOT / "data" / "raw", ROOT / "data" / "raw_increment"
manifest = json.loads((ROOT / "data" / "injection_manifest.json").read_text())
history = json.loads((ROOT / "outputs" / "run_history.json").read_text())


def rd(layer, name):
    return pd.read_parquet(LAKE / layer / name)


def csv_rows(folder, name):
    with open(folder / f"{name}.csv", "rb") as f:
        return sum(1 for _ in f) - 1


results = []


def test(tid, name, method, expected, fn):
    t0 = time.perf_counter()
    try:
        ok, actual = fn()
        status = "PASS" if ok else "FAIL"
    except Exception as e:                                   # a crashing test is a failing test
        status, actual = "FAIL", f"error: {e}"
    results.append({"id": tid, "check": name, "method": method, "expected": expected, "actual": str(actual),
                    "status": status, "seconds": round(time.perf_counter() - t0, 2)})
    print(f"{tid} {status:4} {name} -> {actual}")


TABLES = ["orders", "order_items", "customers", "products", "payments", "reviews"]
bronze = {t: rd("bronze", t) for t in TABLES}
silver = {t: rd("silver", t) for t in TABLES}
quar = rd("silver", "quarantine")
qc = quar.groupby(["source_table", "reason"]).size().to_dict()
inc = manifest["incremental"]

# T01
def t01():
    exp = {t: csv_rows(RAW, t) + csv_rows(INC, t) for t in TABLES}
    act = {t: len(bronze[t]) for t in TABLES}
    return exp == act, act
test("T01", "Bronze row count equals source files (main + incremental)", "Count CSV lines vs Bronze rows", "Equal for all 6 tables", t01)

# T02
KEYS = {"orders": ["order_id", "customer_id"], "order_items": ["order_id", "product_id"], "customers": ["customer_id"],
        "payments": ["order_id"], "reviews": ["review_id", "order_id"], "products": ["product_id"]}
def t02():
    bad = {t: int(silver[t][k].isna().any(axis=1).sum()) for t, k in KEYS.items()}
    return sum(bad.values()) == 0, bad
test("T02", "No null keys in Silver", "isna() on key columns", "0 rows per table", t02)

# T03
BK = {"orders": ["order_id"], "order_items": ["order_id", "order_item_id"], "customers": ["customer_id"],
      "products": ["product_id"], "payments": ["order_id", "payment_sequential"], "reviews": ["review_id"]}
def t03():
    bad = {t: int(silver[t].duplicated(k).sum()) for t, k in BK.items()}
    return sum(bad.values()) == 0, bad
test("T03", "No duplicate business keys in Silver", "duplicated() on business key", "0 rows per table", t03)

# T04
def t04():
    o = silver["orders"]
    n = int((o.delivered_ts < o.purchase_ts).sum())
    return n == 0, f"{n} rows"
test("T04", "No delivery date before purchase date in Silver", "Compare timestamps", "0 rows", t04)

# T05
def t05():
    exp = {("orders", "NULL_KEY"): manifest["orders"]["null_order_id"] + manifest["orders"]["null_customer_id"],
           ("orders", "INVALID_TIMESTAMP"): manifest["orders"]["unparseable_purchase_ts"],
           ("orders", "DELIVERY_BEFORE_PURCHASE"): manifest["orders"]["delivered_before_purchase"],
           ("orders", "DUPLICATE_KEY"): manifest["orders"]["duplicate_rows"],
           ("order_items", "NULL_KEY"): manifest["order_items"]["null_product_id"] + manifest["order_items"]["null_order_id"],
           ("order_items", "INVALID_AMOUNT"): manifest["order_items"]["negative_price"],
           ("order_items", "DUPLICATE_KEY"): manifest["order_items"]["duplicate_rows"],
           ("payments", "NULL_KEY"): manifest["payments"]["null_order_id"],
           ("payments", "NON_POSITIVE_PAYMENT"): manifest["payments"]["negative_value"],
           ("payments", "DUPLICATE_KEY"): manifest["payments"]["duplicate_rows"],
           ("reviews", "INVALID_SCORE"): manifest["reviews"]["score_out_of_range"],
           ("reviews", "DUPLICATE_KEY"): manifest["reviews"]["duplicate_rows"]}
    act = {k: qc.get(k, 0) for k in exp}
    diff = {f"{k[0]}.{k[1]}": (exp[k], act[k]) for k in exp if exp[k] != act[k]}
    return not diff, f"all {len(exp)} rules match the injected counts" if not diff else f"mismatch (expected, actual): {diff}"
test("T05", "Every injected problem is caught in exactly the injected number", "Quarantine reason counts vs data/injection_manifest.json", "12 rules, exact match", t05)

# T06
def t06():
    s = silver
    ok = {"state": s["customers"].state.str.fullmatch(r"[A-Z]{2}").all(),
          "status": set(s["orders"].order_status) <= {"delivered", "shipped", "canceled", "unavailable", "invoiced", "processing", "created", "approved"},
          "payment_type": set(s["payments"].payment_type) == {"credit_card", "boleto", "voucher", "debit_card"},
          "category": bool((s["products"].category == s["products"].category.str.lower()).all())}
    return all(ok.values()), {k: bool(v) for k, v in ok.items()}
test("T06", "Text casing is standardised", "Regex and set checks on Silver", "One spelling per value", t06)

# T07
def t07():
    n = int((silver["order_items"].price <= 0).sum() + (silver["payments"].payment_value <= 0).sum())
    return n == 0, f"{n} rows"
test("T07", "No zero or negative price or payment in Silver", "Filter on amounts", "0 rows", t07)

# T08
def t08():
    out = {}
    for t in TABLES:
        diff = len(bronze[t]) - len(silver[t]) - int((quar.source_table == t).sum())
        out[t] = diff
    # the only rows allowed to disappear are the older versions of orders replaced by an update
    ok = all(v == 0 for k, v in out.items() if k != "orders") and out["orders"] == inc["status_updates"]
    return ok, f"unaccounted rows: {out} (orders: {inc['status_updates']} superseded by updates)"
test("T08", "Every Bronze row is in Silver, in quarantine, or replaced by an update", "bronze - silver - quarantine per table", "0 (orders: 40 replaced)", t08)

# T09  independent revenue calculation straight from the CSV files
def t09():
    def load(name):
        return pd.concat([pd.read_csv(RAW / f"{name}.csv", dtype=str), pd.read_csv(INC / f"{name}.csv", dtype=str)], ignore_index=True)
    o, i = load("orders"), load("order_items")
    o["ts"] = pd.to_datetime(o.order_purchase_timestamp, format="%Y-%m-%d %H:%M:%S", errors="coerce")
    o["dl"] = pd.to_datetime(o.order_delivered_customer_date, format="%Y-%m-%d %H:%M:%S", errors="coerce")
    o["st"] = o.order_status.str.strip().str.lower()
    ok = o[o.order_id.notna() & o.customer_id.notna() & o.ts.notna() & ~(o.dl < o.ts)]
    ok = ok.sort_values("order_id").drop_duplicates("order_id", keep="last")      # a later batch row replaces an earlier one
    ok = ok[~ok.st.isin(["canceled", "unavailable"])]
    i["p"] = pd.to_numeric(i.price, errors="coerce")
    i = i[i.order_id.notna() & i.product_id.notna() & i.p.notna() & (i.p > 0)].drop_duplicates(["order_id", "order_item_id"])
    i = i[i.order_id.isin(ok.order_id)]
    exp = int(round(i.p.sum() * 100))
    gold = rd("gold", "daily_sales")
    act = int(round(float(gold.revenue.astype(str).map(Decimal).sum()) * 100))
    return exp == act, f"pandas from raw CSV = {exp/100:,.2f}; Gold daily_sales = {act/100:,.2f}"
test("T09", "Gold revenue equals revenue recalculated independently from the raw CSVs", "pandas re-implementation of the rules", "Difference 0.00", t09)

# T10
def t10():
    r = json.loads((ROOT / "outputs" / "run_metrics.json").read_text())["reconciliation"]
    ok = r["source_equals_quarantine_plus_silver"] and r["silver_equals_gold_plus_excluded"]
    return ok, f"source {r['source_raw_revenue']} = quarantined {r['quarantined_total']} + silver {r['silver_revenue']}; silver = gold {r['gold_revenue']} + excluded {r['excluded_canceled_unavailable']}"
test("T10", "Revenue waterfall balances from raw file to Gold", "Decimal sums logged by the pipeline", "Both identities true", t10)

# T11
def t11():
    fulls = [h["counts"] for h in history if h["mode"] == "full"]
    incs = [h["counts"] for h in history if h["mode"] == "incremental"]
    same_full = all(c == fulls[0] for c in fulls)
    same_inc = len(incs) >= 2 and all(c == incs[-1] for c in incs[-2:])
    return same_full and same_inc, f"{len(fulls)} full loads identical: {same_full}; last 2 incremental loads identical: {same_inc}"
test("T11", "Re-running the pipeline gives identical counts (idempotent)", "Compare counts of repeated runs in run_history.json", "Identical", t11)

# T12
def t12():
    full = [h for h in history if h["mode"] == "full"][-1]["counts"]["silver"]
    now = {t: len(silver[t]) for t in TABLES}
    o = silver["orders"]
    upd = o[o.order_id.isin(pd.read_csv(INC / "orders.csv", dtype=str).query("order_status == 'delivered'").order_id)]
    ok = (now["orders"] - full["orders"] == inc["new_orders"]) and len(upd) == inc["status_updates"] and (upd.order_status == "delivered").all()
    return ok, f"orders {full['orders']} -> {now['orders']} (+{now['orders'] - full['orders']} new); {len(upd)} updated orders now 'delivered', none duplicated"
test("T12", "Incremental MERGE inserts new orders and updates changed ones without duplicates", "Compare Silver before and after the incremental batch", "+600 orders, 40 updated", t12)

# T13
def t13():
    g = rd("gold", "customer_rfm"); f = rd("gold", "fact_order_lines")
    ok = (not g.customer_unique_id.duplicated().any()) and set(g.segment) <= {"Champions", "Loyal", "New high value", "Recent buyers", "At risk", "Lost"} \
        and int(g.monetary.astype(str).map(Decimal).sum() * 100) == int(f.price.astype(str).map(Decimal).sum() * 100)
    return ok, f"{len(g):,} customers, {g.segment.nunique()} segments, RFM monetary total equals fact revenue"
test("T13", "customer_rfm has one row per customer and adds up to Gold revenue", "Uniqueness, segment set and sum", "Unique, totals equal", t13)

# T14
def t14():
    d = rd("gold", "delivery_performance")
    ok = ((d.late_pct >= 0) & (d.late_pct <= 100)).all() and (d.late_orders <= d.delivered_orders).all()
    return bool(ok), f"{len(d)} state-month rows, late_pct between {d.late_pct.min()} and {d.late_pct.max()}"
test("T14", "delivery_performance values are within valid ranges", "Range checks", "0-100 %, late <= delivered", t14)

# T15 regression test for failure 1 (ANSI mode) and unit test of the rules on a tiny frame
def t15():
    from pyspark.sql import SparkSession
    from common import transforms as T
    spark = SparkSession.builder.master("local[1]").config("spark.ui.enabled", "false").config("spark.sql.session.timeZone", "UTC").getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")
    rows = [("o1", "c1", "Delivered", "2018-01-01 10:00:00", None, None, "2018-01-05 10:00:00", "2018-01-10 23:59:59"),
            ("o1", "c1", "Delivered", "2018-01-01 10:00:00", None, None, "2018-01-05 10:00:00", "2018-01-10 23:59:59"),
            (None, "c2", "shipped", "2018-01-02 10:00:00", None, None, None, None),
            ("o3", "c3", "shipped", "31/02/2018 10:00", None, None, None, None),
            ("o4", "c4", "delivered", "2018-02-10 10:00:00", None, None, "2018-02-08 10:00:00", None),
            ("o5", "c5", "DELIVERED", "2018-03-01 08:00:00", None, None, "2018-03-04 08:00:00", "2018-03-09 23:59:59")]
    df = spark.createDataFrame(rows, T.raw_schema("orders")).withColumn("_row_id", __import__("pyspark.sql.functions", fromlist=["x"]).monotonically_increasing_id().cast("string")) \
        .withColumn("_batch_id", __import__("pyspark.sql.functions", fromlist=["x"]).lit("t"))
    good, q = T.clean_orders(df)
    reasons = sorted(r["reason"] for r in q.collect())
    ids = sorted(r["order_id"] for r in good.collect())
    spark.stop()
    ok = reasons == ["DELIVERY_BEFORE_PURCHASE", "DUPLICATE_KEY", "INVALID_TIMESTAMP", "NULL_KEY"] and ids == ["o1", "o5"]
    return ok, f"kept {ids}; quarantined {reasons}"
test("T15", "Rule unit test on 6 hand-made rows, including the bad date that crashed the first run", "clean_orders() on a small DataFrame", "2 kept, 4 quarantined with the right reasons", t15)

# T16 SQL logic check on DuckDB
def t16():
    import duckdb, re
    con = duckdb.connect()
    con.execute("CREATE SCHEMA ANALYTICS")
    for f in (ROOT / "dashboard" / "data").glob("*.csv"):
        pass
    gold = LAKE / "gold"
    for t in ["daily_sales", "top_categories", "delivery_performance", "customer_rfm", "order_status_mix", "payment_type_summary"]:
        df = rd("gold", t)
        for c in df.columns:                                   # decimals as DOUBLE, otherwise DuckDB picks a too-narrow DECIMAL
            if df[c].dtype == object and len(df) and isinstance(df[c].iloc[0], Decimal):
                df[c] = df[c].astype(float)
        con.register("_t", df); con.execute(f"CREATE TABLE ANALYTICS.{t} AS SELECT * FROM _t"); con.unregister("_t")
    sql = (ROOT / "snowflake" / "04_analysis_queries.sql").read_text()
    stmts = [s.strip() for s in re.split(r";\s*\n", sql) if s.strip() and not s.strip().upper().startswith(("--", "USE")) or "SELECT" in s.upper() or "WITH" in s.upper()]
    stmts = [re.sub(r"^(--[^\n]*\n)+", "", s).strip() for s in stmts]
    stmts = [s for s in stmts if s.upper().startswith(("SELECT", "WITH"))]
    con.execute("SET search_path = 'memory.ANALYTICS'")
    outs = {}
    for n, s in enumerate(stmts, 1):
        outs[f"Q{n}"] = len(con.execute(s).fetchall())
    (ROOT / "outputs" / "sql_check_rowcounts.json").write_text(json.dumps(outs))
    return len(stmts) == 10 and all(v > 0 for v in outs.values()), f"{len(stmts)} queries ran on DuckDB, rows returned: {outs}"
test("T16", "All 10 analysis queries run and return rows (DuckDB logic check, not Snowflake)", "Run 04_analysis_queries.sql on the Gold tables in DuckDB", "10 of 10 return rows", t16)

(ROOT / "outputs" / "test_results.json").write_text(json.dumps(results, indent=2))
p = sum(r["status"] == "PASS" for r in results)
print(f"\n{p} of {len(results)} passed")
sys.exit(0 if p == len(results) else 1)
