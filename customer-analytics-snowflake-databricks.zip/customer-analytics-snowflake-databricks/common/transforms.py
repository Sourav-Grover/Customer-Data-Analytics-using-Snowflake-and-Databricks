"""
transforms.py
All Bronze -> Silver -> Gold logic lives here as plain DataFrame functions.
The Databricks notebooks and local_run/run_pipeline_local.py both import this file,
so the laptop run and the cloud run cannot drift apart.
"""
from pyspark.sql import Window
from pyspark.sql import functions as F
from pyspark.sql.types import StringType, StructField, StructType

TS_FMT = "yyyy-MM-dd HH:mm:ss"
EXCLUDED_STATUSES = ["canceled", "unavailable"]   # these orders never turned into revenue

# Bronze schemas are all strings on purpose. If I let Spark infer types, a bad value like
# "31/02/2018 10:00" would silently become null and I could not tell it apart from a real null.
RAW_COLUMNS = {
    "orders": ["order_id", "customer_id", "order_status", "order_purchase_timestamp", "order_approved_at",
               "order_delivered_carrier_date", "order_delivered_customer_date", "order_estimated_delivery_date"],
    "order_items": ["order_id", "order_item_id", "product_id", "seller_id", "shipping_limit_date", "price", "freight_value"],
    "customers": ["customer_id", "customer_unique_id", "customer_zip_code_prefix", "customer_city", "customer_state"],
    "products": ["product_id", "product_category_name", "product_name_length", "product_description_length",
                 "product_photos_qty", "product_weight_g", "product_length_cm", "product_height_cm", "product_width_cm"],
    "payments": ["order_id", "payment_sequential", "payment_type", "payment_installments", "payment_value"],
    "reviews": ["review_id", "order_id", "review_score", "review_comment_title", "review_comment_message",
                "review_creation_date", "review_answer_timestamp"],
}
KEYS = {"orders": ["order_id"], "order_items": ["order_id", "order_item_id"], "customers": ["customer_id"],
        "products": ["product_id"], "payments": ["order_id", "payment_sequential"], "reviews": ["review_id"]}


def raw_schema(table):
    return StructType([StructField(c, StringType(), True) for c in RAW_COLUMNS[table]])


# ------------------------------------------------------------------ Bronze
def read_bronze(spark, path, table, batch_id):
    """Read one source CSV as text and add lineage columns. Nothing is cleaned here."""
    df = spark.read.csv(path, header=True, schema=raw_schema(table), mode="PERMISSIVE")
    cols = RAW_COLUMNS[table]
    df = df.withColumn("_source_file", F.col("_metadata.file_path"))
    # _row_id identifies a source row by its content plus an occurrence number. Exact duplicate rows
    # get #1, #2 ... so they stay distinct, and re-reading the same file always gives the same ids.
    df = df.withColumn("_h", F.sha2(F.to_json(F.struct(*cols)), 256))
    w = Window.partitionBy("_h").orderBy("_h")
    df = df.withColumn("_row_id", F.concat(F.col("_h"), F.lit("#"), F.row_number().over(w).cast("string"))).drop("_h")
    return df.withColumn("_batch_id", F.lit(batch_id)).withColumn("_ingested_at", F.current_timestamp())


# ------------------------------------------------------------------ helpers
def _blank(c):
    return F.col(c).isNull() | (F.trim(F.col(c)) == "")


def _ts(c):
    # Spark 4 has ANSI mode on: plain to_timestamp raises on a bad string instead of returning null,
    # and one bad row would crash the whole job. try_to_timestamp returns null so the row can be quarantined.
    return F.expr(f"try_to_timestamp({c}, '{TS_FMT}')")


def _num(c, typ):
    """Same idea for numbers: a bad value becomes null and is caught by the rules below."""
    return F.expr(f"try_cast({c} AS {typ})")


def _dedupe(df, keys):
    """Keep one row per business key. Extra copies come back tagged so they can go to quarantine."""
    w = Window.partitionBy(*keys).orderBy("_row_id")
    r = df.withColumn("_rn", F.row_number().over(w))
    return (r.filter("_rn = 1").drop("_rn"),
            r.filter("_rn > 1").drop("_rn").withColumn("_reason", F.lit("DUPLICATE_KEY")))


def _quarantine(df, table):
    return df.select(F.lit(table).alias("source_table"), F.col("_reason").alias("reason"),
                     F.concat_ws("|", *[F.coalesce(F.col(k), F.lit("<null>")) for k in KEYS[table]]).alias("record_key"),
                     F.to_json(F.struct(*RAW_COLUMNS[table])).alias("raw_record"),
                     F.col("_row_id"), F.col("_batch_id"), F.current_timestamp().alias("quarantined_at"))


def _split(df, reason_expr):
    """Tag every row with the first rule it breaks. Rows with no reason are good."""
    t = df.withColumn("_reason", reason_expr)
    return t.filter("_reason IS NULL").drop("_reason"), t.filter("_reason IS NOT NULL")


# ------------------------------------------------------------------ Silver
def clean_orders(b):
    t = (b.withColumn("purchase_ts", _ts("order_purchase_timestamp"))
          .withColumn("approved_ts", _ts("order_approved_at"))
          .withColumn("carrier_ts", _ts("order_delivered_carrier_date"))
          .withColumn("delivered_ts", _ts("order_delivered_customer_date"))
          .withColumn("estimated_ts", _ts("order_estimated_delivery_date")))
    reason = (F.when(_blank("order_id") | _blank("customer_id"), "NULL_KEY")
               .when(F.col("purchase_ts").isNull(), "INVALID_TIMESTAMP")
               .when(F.col("delivered_ts") < F.col("purchase_ts"), "DELIVERY_BEFORE_PURCHASE"))
    good, bad = _split(t, reason)
    good, dups = _dedupe(good, KEYS["orders"])
    silver = good.select("order_id", "customer_id", F.lower(F.trim("order_status")).alias("order_status"),
                         "purchase_ts", "approved_ts", "carrier_ts", "delivered_ts", "estimated_ts")
    return silver, _quarantine(bad, "orders").unionByName(_quarantine(dups, "orders"))


def clean_customers(b):
    good, bad = _split(b, F.when(_blank("customer_id") | _blank("customer_unique_id"), "NULL_KEY"))
    good, dups = _dedupe(good, KEYS["customers"])
    silver = good.select("customer_id", "customer_unique_id", _num("customer_zip_code_prefix", "int").alias("zip_prefix"),
                         F.initcap(F.lower(F.trim("customer_city"))).alias("city"), F.upper(F.trim("customer_state")).alias("state"))
    return silver, _quarantine(bad, "customers").unionByName(_quarantine(dups, "customers"))


def clean_products(b):
    good, bad = _split(b, F.when(_blank("product_id"), "NULL_KEY"))
    good, dups = _dedupe(good, KEYS["products"])
    # a missing category is kept as 'unknown' instead of dropping the product, otherwise its sales would vanish
    silver = good.select("product_id", F.coalesce(F.lower(F.trim("product_category_name")), F.lit("unknown")).alias("category"),
                         _num("product_weight_g", "int").alias("weight_g"))
    return silver, _quarantine(bad, "products").unionByName(_quarantine(dups, "products"))


def _orphans(good, valid_orders):
    ids = valid_orders.select("order_id")
    return (good.join(ids, "order_id", "left_semi"),
            good.join(ids, "order_id", "left_anti").withColumn("_reason", F.lit("ORPHAN_ORDER")))


def clean_items(b, valid_orders):
    t = (b.withColumn("price_d", _num("price", "decimal(12,2)"))
          .withColumn("freight_d", _num("freight_value", "decimal(12,2)")))
    reason = (F.when(_blank("order_id") | _blank("product_id") | _blank("order_item_id"), "NULL_KEY")
               .when(F.col("price_d").isNull() | (F.col("price_d") <= 0) | (F.col("freight_d") < 0), "INVALID_AMOUNT"))
    good, bad = _split(t, reason)
    good, dups = _dedupe(good, KEYS["order_items"])
    # dedupe first, then the orphan check, so an extra copy is always reported as a duplicate
    good, orphan = _orphans(good, valid_orders)
    silver = good.select("order_id", _num("order_item_id", "int").alias("order_item_id"), "product_id", "seller_id",
                         F.col("price_d").alias("price"), F.col("freight_d").alias("freight_value"))
    q = _quarantine(bad, "order_items").unionByName(_quarantine(dups, "order_items")).unionByName(_quarantine(orphan, "order_items"))
    return silver, q


def clean_payments(b, valid_orders):
    t = b.withColumn("value_d", _num("payment_value", "decimal(12,2)"))
    reason = (F.when(_blank("order_id") | _blank("payment_sequential"), "NULL_KEY")
               .when(F.col("value_d").isNull() | (F.col("value_d") <= 0), "NON_POSITIVE_PAYMENT"))
    good, bad = _split(t, reason)
    good, dups = _dedupe(good, KEYS["payments"])
    good, orphan = _orphans(good, valid_orders)
    # 'Credit Card', 'CREDIT_CARD' and 'credit_card' are the same thing, so one spelling is enforced
    ptype = F.regexp_replace(F.lower(F.trim("payment_type")), r"\s+", "_")
    silver = good.select("order_id", _num("payment_sequential", "int").alias("payment_sequential"), ptype.alias("payment_type"),
                         _num("payment_installments", "int").alias("installments"), F.col("value_d").alias("payment_value"))
    q = _quarantine(bad, "payments").unionByName(_quarantine(dups, "payments")).unionByName(_quarantine(orphan, "payments"))
    return silver, q


def clean_reviews(b, valid_orders):
    t = (b.withColumn("score_i", _num("review_score", "int"))
          .withColumn("created_ts", _ts("review_creation_date")))
    reason = (F.when(_blank("review_id") | _blank("order_id"), "NULL_KEY")
               .when(F.col("score_i").isNull() | (F.col("score_i") < 1) | (F.col("score_i") > 5), "INVALID_SCORE"))
    good, bad = _split(t, reason)
    good, dups = _dedupe(good, KEYS["reviews"])
    good, orphan = _orphans(good, valid_orders)
    silver = good.select("review_id", "order_id", F.col("score_i").alias("review_score"), F.col("created_ts").alias("review_created_ts"))
    q = _quarantine(bad, "reviews").unionByName(_quarantine(dups, "reviews")).unionByName(_quarantine(orphan, "reviews"))
    return silver, q


def upsert(existing, new, keys):
    """Insert-or-update on business keys. This is the local stand-in for Delta MERGE."""
    return existing.join(new, keys, "left_anti").unionByName(new.select(existing.columns))


# ------------------------------------------------------------------ Gold
def build_fact_lines(orders, items, customers, products):
    """One row per order line, restricted to orders that count as revenue."""
    o = (orders.filter(~F.col("order_status").isin(EXCLUDED_STATUSES))
               .select("order_id", "customer_id", "order_status", F.to_date("purchase_ts").alias("order_date")))
    f = (items.join(o, "order_id")
              .join(customers.select("customer_id", "customer_unique_id", "state"), "customer_id", "left")
              .join(products.select("product_id", "category"), "product_id", "left"))
    return f.select("order_id", "order_item_id", "order_date", F.trunc("order_date", "month").alias("order_month"),
                    "customer_id", "customer_unique_id", F.coalesce("state", F.lit("unknown")).alias("customer_state"),
                    F.coalesce("category", F.lit("unknown")).alias("category"), "price", "freight_value", "order_status")


def gold_daily_sales(fact):
    return (fact.groupBy("order_date")
                .agg(F.countDistinct("order_id").alias("orders"), F.count("*").alias("items_sold"),
                     F.sum("price").alias("revenue"), F.sum("freight_value").alias("freight_value"))
                .withColumn("avg_order_value", F.round(F.col("revenue") / F.col("orders"), 2)))


def gold_top_categories(fact):
    g = (fact.groupBy("order_month", "category")
             .agg(F.countDistinct("order_id").alias("orders"), F.count("*").alias("items_sold"), F.sum("price").alias("revenue")))
    w = Window.partitionBy("order_month").orderBy(F.col("revenue").desc(), F.col("category"))
    return g.withColumn("rank_in_month", F.row_number().over(w))


def gold_delivery_performance(orders, customers, reviews):
    d = (orders.filter((F.col("order_status") == "delivered") & F.col("delivered_ts").isNotNull())
               .join(customers.select("customer_id", F.col("state").alias("customer_state")), "customer_id", "left")
               .join(reviews.groupBy("order_id").agg(F.avg("review_score").alias("order_score")), "order_id", "left"))
    d = (d.withColumn("customer_state", F.coalesce("customer_state", F.lit("unknown")))
          .withColumn("delivery_days", (F.col("delivered_ts").cast("long") - F.col("purchase_ts").cast("long")) / 86400)
          # positive delay means it arrived after the promised date
          .withColumn("delay_days", (F.col("delivered_ts").cast("long") - F.col("estimated_ts").cast("long")) / 86400)
          .withColumn("is_late", (F.col("delivered_ts") > F.col("estimated_ts")).cast("int"))
          .withColumn("order_month", F.trunc(F.to_date("purchase_ts"), "month")))
    return (d.groupBy("customer_state", "order_month")
             .agg(F.count("*").alias("delivered_orders"), F.round(F.avg("delivery_days"), 2).alias("avg_delivery_days"),
                  F.round(F.avg("delay_days"), 2).alias("avg_delay_days"), F.sum("is_late").alias("late_orders"),
                  F.round(F.avg("order_score"), 2).alias("avg_review_score"))
             .withColumn("late_pct", F.round(F.col("late_orders") * 100.0 / F.col("delivered_orders"), 2)))


def gold_customer_rfm(fact):
    c = (fact.filter(F.col("customer_unique_id").isNotNull()).groupBy("customer_unique_id")
             .agg(F.max("order_date").alias("last_order_date"), F.countDistinct("order_id").alias("frequency"),
                  F.sum("price").alias("monetary")))
    ref = fact.agg(F.date_add(F.max("order_date"), 1).alias("ref")).collect()[0]["ref"]
    c = c.withColumn("recency_days", F.datediff(F.lit(ref), F.col("last_order_date")))
    # customer id is the tie-breaker so ntile gives the same buckets on every run
    r = F.ntile(5).over(Window.orderBy(F.col("recency_days").desc(), "customer_unique_id"))
    m = F.ntile(5).over(Window.orderBy(F.col("monetary").asc(), "customer_unique_id"))
    c = (c.withColumn("r_score", r).withColumn("m_score", m)
          .withColumn("f_score", F.when(F.col("frequency") >= 3, 5).when(F.col("frequency") == 2, 3).otherwise(1)))
    seg = (F.when((F.col("frequency") >= 2) & (F.col("r_score") >= 4), "Champions")
            .when(F.col("frequency") >= 2, "Loyal")
            .when((F.col("r_score") >= 4) & (F.col("m_score") >= 4), "New high value")
            .when(F.col("r_score") >= 4, "Recent buyers")
            .when(F.col("r_score") >= 2, "At risk")
            .otherwise("Lost"))
    return c.withColumn("segment", seg)


def gold_order_status_mix(orders):
    g = orders.groupBy("order_status").agg(F.count("*").alias("orders"))
    return g.withColumn("pct", F.round(F.col("orders") * 100.0 / F.sum("orders").over(Window.partitionBy()), 2))


def gold_payment_summary(payments):
    return (payments.groupBy("payment_type")
                    .agg(F.count("*").alias("payments"), F.countDistinct("order_id").alias("orders"),
                         F.sum("payment_value").alias("total_value"), F.round(F.avg("installments"), 2).alias("avg_installments")))
