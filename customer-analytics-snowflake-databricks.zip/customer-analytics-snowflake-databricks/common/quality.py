"""
quality.py
Data quality rule results and the revenue reconciliation, both computed from the
quarantine table so the numbers in the report come straight from the run.
"""
from pyspark.sql import functions as F

RULE_TEXT = {
    ("orders", "NULL_KEY"): "orders: order_id and customer_id are not null",
    ("orders", "INVALID_TIMESTAMP"): "orders: purchase timestamp can be parsed",
    ("orders", "DELIVERY_BEFORE_PURCHASE"): "orders: delivery date is not before purchase date",
    ("orders", "DUPLICATE_KEY"): "orders: order_id is unique",
    ("order_items", "NULL_KEY"): "order_items: order_id and product_id are not null",
    ("order_items", "INVALID_AMOUNT"): "order_items: price is positive",
    ("order_items", "DUPLICATE_KEY"): "order_items: (order_id, order_item_id) is unique",
    ("order_items", "ORPHAN_ORDER"): "order_items: parent order exists in Silver",
    ("payments", "NULL_KEY"): "payments: order_id is not null",
    ("payments", "NON_POSITIVE_PAYMENT"): "payments: payment value is positive",
    ("payments", "DUPLICATE_KEY"): "payments: (order_id, payment_sequential) is unique",
    ("payments", "ORPHAN_ORDER"): "payments: parent order exists in Silver",
    ("reviews", "INVALID_SCORE"): "reviews: score is between 1 and 5",
    ("reviews", "DUPLICATE_KEY"): "reviews: review_id is unique",
    ("reviews", "ORPHAN_ORDER"): "reviews: parent order exists in Silver",
}


def quality_rules(bronze_counts, quarantine):
    """One row per rule: rows checked (Bronze rows of that table), rows failed, pass rate."""
    failed = {(r["source_table"], r["reason"]): r["n"]
              for r in quarantine.groupBy("source_table", "reason").agg(F.count("*").alias("n")).collect()}
    out = []
    for (table, reason), text in RULE_TEXT.items():
        checked = bronze_counts[table]
        bad = failed.get((table, reason), 0)
        out.append({"table": table, "reason": reason, "rule": text, "checked": checked, "failed": bad,
                    "pass_rate": round(100.0 * (checked - bad) / checked, 2) if checked else 100.0})
    return out


def _sum(df, col):
    v = df.agg(F.sum(col)).collect()[0][0]
    return v if v is not None else 0


def reconcile(bronze_items, quarantine, silver_items, silver_orders, gold_daily):
    """Follow every rupee-equivalent of item revenue from the raw file to the Gold table."""
    src = _sum(bronze_items.withColumn("p", F.expr("try_cast(price AS decimal(12,2))")), "p")
    qi = (quarantine.filter("source_table = 'order_items'")
                    .withColumn("p", F.expr("try_cast(get_json_object(raw_record, '$.price') AS decimal(12,2))")))
    by_reason = {r["reason"]: r["s"] for r in qi.groupBy("reason").agg(F.sum("p").alias("s")).collect()}
    silver = _sum(silver_items, "price")
    excluded = _sum(silver_items.join(silver_orders.filter(F.col("order_status").isin("canceled", "unavailable")), "order_id"), "price")
    gold = _sum(gold_daily, "revenue")
    q_total = sum(by_reason.values()) if by_reason else 0
    return {"source_raw_revenue": str(src), "quarantined_by_reason": {k: str(v) for k, v in by_reason.items()},
            "quarantined_total": str(q_total), "silver_revenue": str(silver), "excluded_canceled_unavailable": str(excluded),
            "gold_revenue": str(gold),
            "source_equals_quarantine_plus_silver": src == q_total + silver,
            "silver_equals_gold_plus_excluded": silver == gold + excluded}
