# Capture guide: 6 cloud screenshots

These six screenshots can only be taken from a live Databricks workspace and Snowflake
account. Budget about 20 minutes total.

## Before you start
- Run `databricks/01` through `05` once with `mode=full`, then once more with
  `mode=incremental` (so the Stream/Task history has more than one entry).
- Have `snowflake/04_analysis_queries.sql` and `05_security_tests.sql` open in Snowsight.

## Figure 10.10 — Databricks job run (all 5 notebooks green)
1. Databricks workspace → **Workflows** → create a Job that chains notebooks 01→05.
2. Run it, wait for completion.
3. Screenshot the job run graph showing all 5 tasks succeeded (green ticks).
4. Save as `screenshots/10_10_databricks_job_run.png`.

## Figure 10.11 — Databricks job run details / cluster
1. Click into the completed run from 10.10.
2. Open the **Duration** / **Cluster** tab showing per-task timing and the cluster spec.
3. Save as `screenshots/10_11_databricks_job_details.png`.

## Figure 10.12 — Snowsight: analysis query results
1. In Snowsight, run Q1 and Q3 from `snowflake/04_analysis_queries.sql` as `ANALYST_ROLE`.
2. Screenshot the results grid for both (side by side or stacked).
3. Save as `screenshots/10_12_snowsight_queries.png`.

## Figure 10.13 — Snowsight: Stream/Task history
1. Run `SHOW TASKS IN DATABASE RETAIL_DB;` and the `TASK_HISTORY` query at the bottom
   of `snowflake/03_stream_and_task.sql`.
2. Screenshot both results showing `STATE = SUCCEEDED`.
3. Save as `screenshots/10_13_stream_task_history.png`.

## Figure 10.14 — Warehouse size and auto-suspend
1. Run `SHOW WAREHOUSES LIKE 'RETAIL_WH';`.
2. Screenshot the row showing `SIZE = X-Small`, `AUTO_SUSPEND = 60`.
3. Save as `screenshots/10_14_warehouse_config.png`.

## Figure 10.15 — Security test failures as ANALYST_ROLE
1. Run `snowflake/05_security_tests.sql` while switched to `ANALYST_ROLE`.
2. Screenshot the "Insufficient privileges" errors on the DELETE/INSERT/DROP/ALTER
   statements (each marked `EXPECTED FAIL` in the script).
3. Save as `screenshots/10_15_security_test_failures.png`.

## After capturing
Insert the 6 images into the six slots in Section 10.10–10.15 of the DOCX report, and
update the list of figures / captions if you crop or rename any file.
