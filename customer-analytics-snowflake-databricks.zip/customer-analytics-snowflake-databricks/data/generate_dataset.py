"""
generate_dataset.py
Builds a synthetic e-commerce dataset that follows the Olist Brazilian E-Commerce
table layout (orders, order_items, customers, products, payments, reviews).

This is NOT the real Kaggle data. Everything is generated with numpy seed 42 so the
same files come out on every run. A known number of data problems is injected on
purpose, and the exact counts are written to data/injection_manifest.json so the
pipeline tests can check that every injected problem is caught.

Usage:  python data/generate_dataset.py
"""
import json
import os
import numpy as np
import pandas as pd

SEED = 42
N_ORDERS = 100_000
N_UNIQUE_CUSTOMERS = 91_000        # about 9,000 orders come from repeat customers
N_PRODUCTS = 3_200
N_SELLERS = 520
START, END = pd.Timestamp("2017-01-01"), pd.Timestamp("2018-08-31")
OUT = os.path.join(os.path.dirname(__file__), "raw")
OUT_INC = os.path.join(os.path.dirname(__file__), "raw_increment")

rng = np.random.default_rng(SEED)
fmt = "%Y-%m-%d %H:%M:%S"

# state: (share of customers, extra delivery days for distance from the seller hub in SP)
STATES = {
    "SP": (0.42, 0), "RJ": (0.13, 3), "MG": (0.12, 3), "RS": (0.055, 5), "PR": (0.05, 3),
    "SC": (0.037, 4), "BA": (0.034, 7), "DF": (0.021, 5), "ES": (0.020, 4), "GO": (0.020, 5),
    "PE": (0.017, 9), "CE": (0.013, 10), "PA": (0.010, 12), "MT": (0.009, 8), "MA": (0.007, 11),
    "MS": (0.007, 6), "PB": (0.005, 10), "PI": (0.005, 10), "RN": (0.005, 10), "AL": (0.004, 10),
    "SE": (0.004, 9), "TO": (0.003, 9), "RO": (0.003, 12), "AM": (0.002, 15), "AC": (0.001, 16),
    "AP": (0.001, 15), "RR": (0.0005, 17),
}
CITIES = {"SP": ["sao paulo", "campinas", "guarulhos", "santos"], "RJ": ["rio de janeiro", "niteroi", "petropolis"],
          "MG": ["belo horizonte", "uberlandia", "contagem"], "RS": ["porto alegre", "caxias do sul"],
          "PR": ["curitiba", "londrina"], "SC": ["florianopolis", "joinville"], "BA": ["salvador", "feira de santana"]}
# category: (weight, median price in BRL)
CATS = {
    "bed_bath_table": (0.098, 90), "health_beauty": (0.085, 130), "sports_leisure": (0.077, 110),
    "furniture_decor": (0.074, 85), "computers_accessories": (0.069, 115), "housewares": (0.062, 75),
    "watches_gifts": (0.056, 190), "telephony": (0.041, 60), "garden_tools": (0.036, 95),
    "auto": (0.036, 100), "toys": (0.035, 80), "cool_stuff": (0.032, 105), "perfumery": (0.031, 100),
    "baby": (0.028, 95), "electronics": (0.026, 70), "stationery": (0.023, 45), "fashion_bags_accessories": (0.022, 90),
    "pet_shop": (0.020, 75), "office_furniture": (0.015, 140), "consoles_games": (0.012, 120),
    "luggage_accessories": (0.011, 120), "construction_tools_lights": (0.009, 80), "food": (0.008, 40),
    "books_general_interest": (0.007, 45), "musical_instruments": (0.006, 180), "home_appliances": (0.006, 130),
    "small_appliances": (0.006, 220), "fashion_shoes": (0.005, 100), "market_place": (0.004, 60),
    "furniture_living_room": (0.004, 130),
}


def choice_p(items, p, size):
    p = np.array(p, dtype=float)
    return rng.choice(items, size=size, p=p / p.sum())


def make_ids(n, prefix_seed):
    """32-char hex ids like the real dataset uses."""
    raw = rng.integers(0, 2**63 - 1, size=(n, 2), dtype=np.int64)
    ids = [f"{a:016x}{b:016x}" for a, b in raw]
    assert len(set(ids)) == n
    return ids


def build_batch(n_orders, start, end, growth, customers_pool=None, order_ids=None):
    """Generate one consistent set of six tables for n_orders orders between start and end."""
    days = pd.date_range(start, end, freq="D")
    t = np.linspace(0, 1, len(days))
    w = (1 + 6.5 * t) * np.where(days.dayofweek >= 5, 0.85, 1.0)
    w = w * np.where((days.year == 2017) & (days.month == 11), 1.55, 1.0)      # black friday month
    w = w * np.where((days.month == 12), 0.9, 1.0) * (growth if growth else 1)
    d = rng.choice(len(days), size=n_orders, p=w / w.sum())
    hour = choice_p(np.arange(24), [1, .5, .3, .2, .2, .3, .8, 2, 4, 5.5, 6.5, 6.5, 6, 6, 6.5, 6.5, 6, 6, 6.5, 7, 7.5, 8, 6, 3], n_orders)
    purchase = (days[d].values.astype("datetime64[s]") + hour.astype("timedelta64[h]").astype("timedelta64[s]")
                + rng.integers(0, 3600, n_orders).astype("timedelta64[s]"))
    purchase = pd.to_datetime(purchase)
    order_id = order_ids if order_ids is not None else make_ids(n_orders, 1)
    customer_id = make_ids(n_orders, 2)
    return days, purchase, np.array(order_id), np.array(customer_id)


def main():
    os.makedirs(OUT, exist_ok=True)
    os.makedirs(OUT_INC, exist_ok=True)
    manifest = {"seed": SEED, "generator": "data/generate_dataset.py", "note": "synthetic data shaped like Olist, not the Kaggle files"}

    # ---------------- reference tables ----------------
    cat_names = list(CATS)
    prod_cat = choice_p(cat_names, [CATS[c][0] for c in cat_names], N_PRODUCTS)
    base_price = np.array([CATS[c][1] for c in prod_cat]) * rng.lognormal(0, 0.55, N_PRODUCTS)
    base_price = np.clip(base_price, 6, 3500).round(2)
    product_id = make_ids(N_PRODUCTS, 3)
    products = pd.DataFrame({
        "product_id": product_id, "product_category_name": prod_cat,
        "product_name_length": rng.integers(20, 70, N_PRODUCTS), "product_description_length": rng.integers(80, 2500, N_PRODUCTS),
        "product_photos_qty": rng.integers(1, 8, N_PRODUCTS), "product_weight_g": rng.integers(80, 12000, N_PRODUCTS),
        "product_length_cm": rng.integers(10, 80, N_PRODUCTS), "product_height_cm": rng.integers(2, 60, N_PRODUCTS),
        "product_width_cm": rng.integers(8, 60, N_PRODUCTS)})
    seller_ids = make_ids(N_SELLERS, 4)
    prod_seller = rng.choice(seller_ids, N_PRODUCTS)
    # popularity: a few products sell far more than the rest
    pop = rng.pareto(1.6, N_PRODUCTS) + 1

    # ---------------- main batch ----------------
    days, purchase, order_id, customer_id = build_batch(N_ORDERS, START, END, None)
    uniq_id = make_ids(N_UNIQUE_CUSTOMERS, 5)
    assign = np.concatenate([np.arange(N_UNIQUE_CUSTOMERS), rng.integers(0, N_UNIQUE_CUSTOMERS, N_ORDERS - N_UNIQUE_CUSTOMERS)])
    rng.shuffle(assign)
    st_names = list(STATES)
    uniq_state = choice_p(st_names, [STATES[s][0] for s in st_names], N_UNIQUE_CUSTOMERS)
    uniq_city = np.array([rng.choice(CITIES.get(s, [s.lower() + " city", s.lower() + " capital"])) for s in uniq_state])
    uniq_zip = rng.integers(1000, 99999, N_UNIQUE_CUSTOMERS)
    customers = pd.DataFrame({
        "customer_id": customer_id, "customer_unique_id": np.array(uniq_id)[assign],
        "customer_zip_code_prefix": uniq_zip[assign], "customer_city": uniq_city[assign], "customer_state": uniq_state[assign]})
    ostate = uniq_state[assign]
    extra = np.array([STATES[s][1] for s in ostate])

    status = choice_p(["delivered", "shipped", "canceled", "unavailable", "invoiced", "processing", "created", "approved"],
                      [97.0, 1.1, 0.6, 0.6, 0.3, 0.3, 0.05, 0.05], N_ORDERS)
    approve = purchase + pd.to_timedelta(rng.exponential(25, N_ORDERS), unit="m")
    carrier = approve + pd.to_timedelta(rng.uniform(0.4, 3.5, N_ORDERS), unit="D")
    deliv_days = rng.lognormal(np.log(9.5), 0.55, N_ORDERS) + extra * 0.85
    delivered = purchase + pd.to_timedelta(deliv_days, unit="D")
    estimated = (purchase + pd.to_timedelta(np.round(20.5 + extra * 0.9 + rng.normal(0, 3.2, N_ORDERS)), unit="D")).normalize() + pd.Timedelta(hours=23, minutes=59, seconds=59)
    orders = pd.DataFrame({"order_id": order_id, "customer_id": customer_id, "order_status": status,
                           "order_purchase_timestamp": purchase, "order_approved_at": approve,
                           "order_delivered_carrier_date": carrier, "order_delivered_customer_date": delivered,
                           "order_estimated_delivery_date": estimated})
    not_delivered = orders.order_status != "delivered"
    orders.loc[not_delivered, "order_delivered_customer_date"] = pd.NaT
    orders.loc[orders.order_status.isin(["created"]), ["order_approved_at", "order_delivered_carrier_date"]] = pd.NaT
    orders.loc[orders.order_status.isin(["approved", "invoiced", "processing", "canceled", "unavailable"]), "order_delivered_carrier_date"] = pd.NaT
    # shipped orders that will be updated to delivered in the incremental batch
    shipped_ids = orders.loc[orders.order_status == "shipped", "order_id"].values

    # ---------------- order items ----------------
    n_items = choice_p([1, 2, 3, 4, 5], [88, 9, 2, .7, .3], N_ORDERS)
    rep = np.repeat(np.arange(N_ORDERS), n_items)
    item_no = np.concatenate([np.arange(1, k + 1) for k in n_items])
    pidx = rng.choice(N_PRODUCTS, size=len(rep), p=pop / pop.sum())
    price = (base_price[pidx] * rng.uniform(0.92, 1.08, len(rep))).round(2)
    freight = np.clip((9 + 0.045 * price + 0.6 * extra[rep] + rng.gamma(2, 2.2, len(rep))), 4, None).round(2)
    items = pd.DataFrame({"order_id": order_id[rep], "order_item_id": item_no, "product_id": np.array(product_id)[pidx],
                          "seller_id": prod_seller[pidx], "shipping_limit_date": (purchase[rep] + pd.Timedelta(days=4)),
                          "price": price, "freight_value": freight})

    # ---------------- payments ----------------
    total = items.groupby("order_id")[["price", "freight_value"]].sum().sum(axis=1).reindex(order_id).values
    ptype = choice_p(["credit_card", "boleto", "voucher", "debit_card"], [74, 19.5, 4.2, 2.3], N_ORDERS)
    split = (rng.random(N_ORDERS) < 0.035) & (ptype == "credit_card")
    p1 = pd.DataFrame({"order_id": order_id, "payment_sequential": 1, "payment_type": ptype,
                       "payment_installments": np.where(ptype == "credit_card", rng.choice([1, 2, 3, 4, 5, 6, 8, 10], N_ORDERS, p=[.5, .12, .1, .07, .05, .06, .04, .06]), 1),
                       "payment_value": np.where(split, (total * 0.7), total).round(2)})
    p2 = pd.DataFrame({"order_id": order_id[split], "payment_sequential": 2, "payment_type": "voucher", "payment_installments": 1,
                       "payment_value": (total[split] - (total[split] * 0.7).round(2)).round(2)})
    payments = pd.concat([p1, p2], ignore_index=True)

    # ---------------- reviews ----------------
    has_rev = rng.random(N_ORDERS) < 0.985
    late = (orders.order_delivered_customer_date > orders.order_estimated_delivery_date).values
    score = np.where(late, choice_p([1, 2, 3, 4, 5], [38, 12, 12, 16, 22], N_ORDERS), choice_p([1, 2, 3, 4, 5], [7, 2.5, 7, 19, 64.5], N_ORDERS))
    rev_base = orders.order_delivered_customer_date.fillna(orders.order_purchase_timestamp + pd.Timedelta(days=12))
    msgs = np.array(["entrega rapida", "produto chegou com defeito", "recomendo a loja", "atraso na entrega", "otimo custo beneficio", "nao recebi o produto"])
    has_msg = rng.random(N_ORDERS) < 0.4
    reviews = pd.DataFrame({"review_id": make_ids(N_ORDERS, 6), "order_id": order_id, "review_score": score,
                            "review_comment_title": None, "review_comment_message": np.where(has_msg, rng.choice(msgs, N_ORDERS), None),
                            "review_creation_date": (rev_base + pd.to_timedelta(rng.uniform(1, 5, N_ORDERS), unit="D")).dt.normalize(),
                            "review_answer_timestamp": rev_base + pd.to_timedelta(rng.uniform(2, 9, N_ORDERS), unit="D")})[has_rev].reset_index(drop=True)

    # ---------------- incremental batch (new week + status updates) ----------------
    N_INC = 600
    inc_days, inc_purchase, inc_order_id, inc_customer_id = build_batch(N_INC, pd.Timestamp("2018-09-01"), pd.Timestamp("2018-09-07"), None)
    inc_customers_uniq = rng.integers(0, N_UNIQUE_CUSTOMERS, N_INC)
    inc_state = uniq_state[inc_customers_uniq]
    inc_extra = np.array([STATES[s][1] for s in inc_state])
    inc_orders = pd.DataFrame({
        "order_id": inc_order_id, "customer_id": inc_customer_id, "order_status": "processing",
        "order_purchase_timestamp": inc_purchase, "order_approved_at": inc_purchase + pd.Timedelta(minutes=30),
        "order_delivered_carrier_date": pd.NaT, "order_delivered_customer_date": pd.NaT,
        "order_estimated_delivery_date": (inc_purchase + pd.to_timedelta(19 + inc_extra, unit="D")).normalize() + pd.Timedelta(hours=23, minutes=59, seconds=59)})
    inc_customers = pd.DataFrame({"customer_id": inc_customer_id, "customer_unique_id": np.array(uniq_id)[inc_customers_uniq],
                                  "customer_zip_code_prefix": uniq_zip[inc_customers_uniq], "customer_city": uniq_city[inc_customers_uniq],
                                  "customer_state": inc_state})
    ik = choice_p([1, 2, 3], [88, 10, 2], N_INC)
    irep = np.repeat(np.arange(N_INC), ik)
    ipidx = rng.choice(N_PRODUCTS, size=len(irep), p=pop / pop.sum())
    iprice = (base_price[ipidx] * rng.uniform(0.92, 1.08, len(irep))).round(2)
    ifr = np.clip(9 + 0.045 * iprice + 0.6 * inc_extra[irep] + rng.gamma(2, 2.2, len(irep)), 4, None).round(2)
    inc_items = pd.DataFrame({"order_id": inc_order_id[irep], "order_item_id": np.concatenate([np.arange(1, k + 1) for k in ik]),
                              "product_id": np.array(product_id)[ipidx], "seller_id": prod_seller[ipidx],
                              "shipping_limit_date": inc_purchase[irep] + pd.Timedelta(days=4), "price": iprice, "freight_value": ifr})
    itot = inc_items.groupby("order_id")[["price", "freight_value"]].sum().sum(axis=1).reindex(inc_order_id).values
    inc_pay = pd.DataFrame({"order_id": inc_order_id, "payment_sequential": 1, "payment_type": choice_p(["credit_card", "boleto", "voucher", "debit_card"], [74, 19.5, 4.2, 2.3], N_INC),
                            "payment_installments": 1, "payment_value": itot.round(2)})
    # 40 previously shipped orders come back as delivered (same order_id, changed row -> MERGE must update, not duplicate)
    upd_ids = shipped_ids[:40]
    upd = orders[orders.order_id.isin(upd_ids)].copy()
    upd["order_status"] = "delivered"
    upd["order_delivered_customer_date"] = upd.order_purchase_timestamp + pd.Timedelta(days=13)
    inc_orders = pd.concat([inc_orders, upd], ignore_index=True)
    manifest["incremental"] = {"new_orders": N_INC, "status_updates": int(len(upd_ids)), "new_items": int(len(inc_items))}

    # ---------------- inject problems into the main batch ----------------
    perm = rng.permutation(N_ORDERS)
    cut = lambda a, b: perm[a:b]
    idx_null_oid, idx_null_cid, idx_bad_ts, idx_bad_dates = cut(0, 40), cut(40, 160), cut(160, 185), cut(185, 1485)
    used = set(perm[:1485])
    clean_pool = np.array([i for i in perm[1485:]])
    idx_dup_orders = clean_pool[:1500]
    orders_out = orders.copy()
    for c in ["order_purchase_timestamp", "order_approved_at", "order_delivered_carrier_date", "order_delivered_customer_date", "order_estimated_delivery_date"]:
        orders_out[c] = orders_out[c].dt.strftime(fmt)
    # invalid dates: delivered before purchase (only on delivered orders, so re-pick from delivered ones)
    delivered_idx = np.where(orders.order_status.values == "delivered")[0]
    delivered_idx = np.array([i for i in delivered_idx if i not in set(idx_null_oid) | set(idx_null_cid) | set(idx_bad_ts)])
    idx_bad_dates = rng.choice(delivered_idx, 1300, replace=False)
    dset = set(idx_bad_dates)
    idx_dup_orders = np.array([i for i in clean_pool if i not in dset][:1500])
    orders_out.loc[idx_bad_dates, "order_delivered_customer_date"] = (orders.loc[idx_bad_dates, "order_purchase_timestamp"] - pd.to_timedelta(rng.uniform(1, 6, 1300), unit="D")).dt.strftime(fmt).values
    orders_out.loc[idx_null_oid, "order_id"] = None
    orders_out.loc[idx_null_cid, "customer_id"] = None
    orders_out.loc[idx_bad_ts, "order_purchase_timestamp"] = "31/02/2018 10:00"      # unparseable, not a real date
    # casing noise on order_status
    cs = rng.choice(N_ORDERS, 3000, replace=False)
    orders_out.loc[cs[:1500], "order_status"] = orders_out.loc[cs[:1500], "order_status"].str.upper()
    orders_out.loc[cs[1500:], "order_status"] = orders_out.loc[cs[1500:], "order_status"].str.capitalize()
    # keep the injected sets clean of the casing pass counts (casing does not fail any rule, only needs standardising)
    orders_out = pd.concat([orders_out, orders_out.loc[idx_dup_orders]], ignore_index=True)
    manifest["orders"] = {"base_rows": N_ORDERS, "duplicate_rows": len(idx_dup_orders), "null_order_id": 40, "null_customer_id": 120,
                          "unparseable_purchase_ts": 25, "delivered_before_purchase": 1300, "status_case_changed": 3000}

    cust_out = customers.copy()
    ci = rng.choice(N_ORDERS, 9000, replace=False)
    cust_out.loc[ci[:4000], "customer_state"] = cust_out.loc[ci[:4000], "customer_state"].str.lower()
    cust_out.loc[ci[4000:6000], "customer_state"] = " " + cust_out.loc[ci[4000:6000], "customer_state"] + " "
    cust_out.loc[ci[6000:], "customer_city"] = cust_out.loc[ci[6000:], "customer_city"].str.upper()
    manifest["customers"] = {"state_or_city_case_or_space_changed": 9000}

    prod_out = products.copy()
    pi = rng.choice(N_PRODUCTS, 260, replace=False)
    prod_out.loc[pi[:120], "product_category_name"] = prod_out.loc[pi[:120], "product_category_name"].str.upper()
    prod_out.loc[pi[120:220], "product_category_name"] = prod_out.loc[pi[120:220], "product_category_name"].str.title()
    prod_out.loc[pi[220:], "product_category_name"] = None
    manifest["products"] = {"category_case_changed": 220, "category_null": 40}

    items_out = items.copy()
    ii = rng.permutation(len(items_out))
    dup_items = items_out.iloc[ii[200:1000]]
    items_out.loc[items_out.index[ii[:60]], "product_id"] = None
    items_out.loc[items_out.index[ii[60:90]], "order_id"] = None
    items_out.loc[items_out.index[ii[90:120]], "price"] = -items_out.loc[items_out.index[ii[90:120]], "price"]
    items_out["shipping_limit_date"] = items_out["shipping_limit_date"].dt.strftime(fmt)
    dup_items = dup_items.copy(); dup_items["shipping_limit_date"] = dup_items["shipping_limit_date"].dt.strftime(fmt)
    items_out = pd.concat([items_out, dup_items], ignore_index=True)
    manifest["order_items"] = {"base_rows": int(len(items)), "null_product_id": 60, "null_order_id": 30, "negative_price": 30, "duplicate_rows": 800}
    # the injected rows above were picked from ii[:200] (not duplicated) and ii[200:1000] (duplicated, unmodified)

    pay_out = payments.copy()
    pp = rng.permutation(len(pay_out))
    dup_pay = pay_out.iloc[pp[100:600]].copy()
    pay_out.loc[pay_out.index[pp[:25]], "payment_value"] = -pay_out.loc[pay_out.index[pp[:25]], "payment_value"]
    pay_out.loc[pay_out.index[pp[25:45]], "order_id"] = None
    ptc = rng.choice(len(pay_out), 3000, replace=False)
    pay_out.loc[pay_out.index[ptc[:1500]], "payment_type"] = pay_out.loc[pay_out.index[ptc[:1500]], "payment_type"].str.title().str.replace("_", " ")
    pay_out.loc[pay_out.index[ptc[1500:]], "payment_type"] = pay_out.loc[pay_out.index[ptc[1500:]], "payment_type"].str.upper()
    pay_out = pd.concat([pay_out, dup_pay], ignore_index=True)
    manifest["payments"] = {"base_rows": int(len(payments)), "negative_value": 25, "null_order_id": 20, "duplicate_rows": 500, "type_case_changed": 3000}

    rev_out = reviews.copy()
    rr = rng.permutation(len(rev_out))
    dup_rev = rev_out.iloc[rr[50:350]].copy()
    rev_out.loc[rev_out.index[rr[:15]], "review_score"] = rng.choice([0, 6], 15)
    for c in ["review_creation_date", "review_answer_timestamp"]:
        rev_out[c] = rev_out[c].dt.strftime(fmt); dup_rev[c] = dup_rev[c].dt.strftime(fmt)
    rev_out = pd.concat([rev_out, dup_rev], ignore_index=True)
    manifest["reviews"] = {"base_rows": int(len(reviews)), "score_out_of_range": 15, "duplicate_rows": 300}

    # shuffle so problems are not grouped at the end of a file
    def shuf(df): return df.sample(frac=1, random_state=SEED).reset_index(drop=True)
    for name, df in [("orders", orders_out), ("order_items", items_out), ("customers", cust_out), ("products", prod_out),
                     ("payments", pay_out), ("reviews", rev_out)]:
        shuf(df).to_csv(os.path.join(OUT, f"{name}.csv"), index=False)

    # incremental files are clean-format apart from the casing they share with the main batch
    def dt(df, cols):
        df = df.copy()
        for c in cols: df[c] = df[c].dt.strftime(fmt)
        return df
    dt(inc_orders, ["order_purchase_timestamp", "order_approved_at", "order_delivered_carrier_date", "order_delivered_customer_date", "order_estimated_delivery_date"]).to_csv(os.path.join(OUT_INC, "orders.csv"), index=False)
    dt(inc_items, ["shipping_limit_date"]).to_csv(os.path.join(OUT_INC, "order_items.csv"), index=False)
    inc_customers.to_csv(os.path.join(OUT_INC, "customers.csv"), index=False)
    inc_pay.to_csv(os.path.join(OUT_INC, "payments.csv"), index=False)
    pd.DataFrame(columns=reviews.columns).to_csv(os.path.join(OUT_INC, "reviews.csv"), index=False)
    pd.DataFrame(columns=products.columns).to_csv(os.path.join(OUT_INC, "products.csv"), index=False)

    with open(os.path.join(os.path.dirname(__file__), "injection_manifest.json"), "w") as f:
        json.dump(manifest, f, indent=2)
    for n in ["orders", "order_items", "customers", "products", "payments", "reviews"]:
        print(n, sum(1 for _ in open(os.path.join(OUT, f"{n}.csv"))) - 1)
    print(json.dumps(manifest, indent=1))


if __name__ == "__main__":
    main()
