# Databricks notebook source
# MAGIC %md
# MAGIC # 03 Gold aggregates
# MAGIC Gold is small and cheap to build, so every run rebuilds it from Silver with an overwrite.
# MAGIC
# MAGIC | Table | One row per | Business question |
# MAGIC |---|---|---|
# MAGIC | daily_sales | day | How much revenue and how many orders did each day bring? |
# MAGIC | top_categories | category and month | Which categories sell best in each month? |
# MAGIC | delivery_performance | state and month | Where are deliveries late, and by how many days? |
# MAGIC | customer_rfm | customer | Who bought recently, often and for the most money? |

# COMMAND ----------
import os, sys
sys.path.append(os.path.abspath(".."))
from common import transforms as T

dbutils.widgets.text("catalog", "retail")
CATALOG = dbutils.widgets.get("catalog")
spark.sql(f"CREATE SCHEMA IF NOT EXISTS {CATALOG}.gold")
s = lambda t: spark.table(f"{CATALOG}.silver.{t}")

# COMMAND ----------
fact = T.build_fact_lines(s("orders"), s("order_items"), s("customers"), s("products"))
outputs = {
    "fact_order_lines": fact,
    "daily_sales": T.gold_daily_sales(fact),
    "top_categories": T.gold_top_categories(fact),
    "delivery_performance": T.gold_delivery_performance(s("orders"), s("customers"), s("reviews")),
    "customer_rfm": T.gold_customer_rfm(fact),
    "order_status_mix": T.gold_order_status_mix(s("orders")),
    "payment_type_summary": T.gold_payment_summary(s("payments")),
}
for name, df in outputs.items():
    df.write.format("delta").mode("overwrite").option("overwriteSchema", "true").saveAsTable(f"{CATALOG}.gold.{name}")
    print(name, spark.table(f"{CATALOG}.gold.{name}").count())

# COMMAND ----------
# MAGIC %sql
# MAGIC -- Time travel: read the table as it was one version ago (works after the second run)
# MAGIC SELECT COUNT(*) AS rows_now FROM retail.gold.daily_sales;
# MAGIC -- SELECT COUNT(*) FROM retail.gold.daily_sales VERSION AS OF 0;
