# Databricks notebook source
# MAGIC %md
# MAGIC # 05 Data quality checks
# MAGIC Hard assertions on Silver and Gold. If any check fails the notebook raises, so the Databricks Job run shows red
# MAGIC and the Snowflake load never starts.

# COMMAND ----------
import os, sys
sys.path.append(os.path.abspath(".."))
from pyspark.sql import functions as F
from common import transforms as T
from common.quality import quality_rules, reconcile

dbutils.widgets.text("catalog", "retail")
C = dbutils.widgets.get("catalog")
t = lambda layer, name: spark.table(f"{C}.{layer}.{name}")
failures = []

def check(name, bad_rows):
    print(("PASS " if bad_rows == 0 else "FAIL ") + f"{name} (bad rows: {bad_rows})")
    if bad_rows:
        failures.append(name)

# COMMAND ----------
# CP1: Bronze must hold every row of the source files. Two dbutils widgets keep this notebook reusable for the batch run.
dbutils.widgets.text("raw_path", "/Volumes/retail/landing/raw")
dbutils.widgets.text("inc_path", "")
RAW, INC = dbutils.widgets.get("raw_path"), dbutils.widgets.get("inc_path")
def source_rows(name):
    n = spark.read.csv(f"{RAW}/{name}.csv", header=True, schema=T.raw_schema(name)).count()
    if INC:
        n += spark.read.csv(f"{INC}/{name}.csv", header=True, schema=T.raw_schema(name)).count()
    return n
for name in T.RAW_COLUMNS:
    check(f"bronze.{name}: row count equals source files", abs(t("bronze", name).count() - source_rows(name)))

# COMMAND ----------
o, i, p = t("silver", "orders"), t("silver", "order_items"), t("silver", "payments")
check("silver.orders: no null keys", o.filter("order_id IS NULL OR customer_id IS NULL").count())
check("silver.orders: order_id unique", o.count() - o.select("order_id").distinct().count())
check("silver.orders: delivery not before purchase", o.filter("delivered_ts < purchase_ts").count())
check("silver.order_items: price positive", i.filter("price <= 0").count())
check("silver.order_items: no orphan items", i.join(o, "order_id", "left_anti").count())
check("silver.payments: value positive", p.filter("payment_value <= 0").count())
check("silver.payments: type is lower snake case", p.filter("payment_type != lower(payment_type) OR payment_type LIKE '% %'").count())
check("silver.customers: state is 2 upper-case letters", t("silver", "customers").filter("state NOT RLIKE '^[A-Z]{2}$'").count())

# COMMAND ----------
# Revenue must be explainable from the raw file to Gold, with nothing lost and nothing invented
rec = reconcile(t("bronze", "order_items"), t("silver", "quarantine"), i, o, t("gold", "daily_sales"))
print(rec)
check("revenue: source = quarantined + silver", 0 if rec["source_equals_quarantine_plus_silver"] else 1)
check("revenue: silver = gold + excluded statuses", 0 if rec["silver_equals_gold_plus_excluded"] else 1)

# COMMAND ----------
counts = {n: t("bronze", n).count() for n in T.RAW_COLUMNS}
display(spark.createDataFrame(quality_rules(counts, t("silver", "quarantine"))))
if failures:
    raise Exception(f"Data quality checks failed: {failures}")
