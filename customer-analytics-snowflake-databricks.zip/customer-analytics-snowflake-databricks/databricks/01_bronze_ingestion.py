# Databricks notebook source
# MAGIC %md
# MAGIC # 01 Bronze ingestion
# MAGIC Copies the source CSVs into Delta tables as text, plus lineage columns. No cleaning happens here.
# MAGIC Full load = overwrite. Incremental = insert only the rows whose `_row_id` is not stored yet.

# COMMAND ----------
import os, sys
sys.path.append(os.path.abspath(".."))          # repo root, so `common` imports when the repo is cloned into Databricks Repos
from delta.tables import DeltaTable
from common import transforms as T

dbutils.widgets.dropdown("mode", "full", ["full", "incremental"])
dbutils.widgets.text("catalog", "retail")
dbutils.widgets.text("raw_path", "/Volumes/retail/landing/raw")          # folder holding the six CSVs
dbutils.widgets.text("batch_id", "full_load")
MODE, CATALOG = dbutils.widgets.get("mode"), dbutils.widgets.get("catalog")
RAW_PATH, BATCH_ID = dbutils.widgets.get("raw_path"), dbutils.widgets.get("batch_id")

spark.sql(f"CREATE SCHEMA IF NOT EXISTS {CATALOG}.bronze")

# COMMAND ----------
for table in T.RAW_COLUMNS:
    df = T.read_bronze(spark, f"{RAW_PATH}/{table}.csv", table, BATCH_ID)
    target = f"{CATALOG}.bronze.{table}"
    if MODE == "full" or not spark.catalog.tableExists(target):
        # overwrite is safe to repeat: running the notebook twice leaves one copy of the data, not two
        df.write.format("delta").mode("overwrite").option("overwriteSchema", "true").saveAsTable(target)
    else:
        # MERGE with only a "not matched" branch = append rows we have not seen before
        (DeltaTable.forName(spark, target).alias("t")
            .merge(df.alias("s"), "t._row_id = s._row_id")
            .whenNotMatchedInsertAll().execute())
    print(table, spark.table(target).count())

# COMMAND ----------
# MAGIC %sql
# MAGIC -- Delta keeps a version per write. This is what the "Delta history" screenshot in the report shows.
# MAGIC DESCRIBE HISTORY retail.bronze.orders
