# Databricks notebook source
# MAGIC %md
# MAGIC # 02 Silver cleaning
# MAGIC Types, standardises and validates Bronze. Rows that break a rule go to `silver.quarantine` with the reason.
# MAGIC Full load = overwrite. Incremental = MERGE on the business key (new rows inserted, changed rows updated).

# COMMAND ----------
import os, sys
sys.path.append(os.path.abspath(".."))
from delta.tables import DeltaTable
from pyspark.sql import functions as F
from common import transforms as T

dbutils.widgets.dropdown("mode", "full", ["full", "incremental"])
dbutils.widgets.text("catalog", "retail")
dbutils.widgets.text("batch_id", "full_load")
MODE, CATALOG, BATCH_ID = dbutils.widgets.get("mode"), dbutils.widgets.get("catalog"), dbutils.widgets.get("batch_id")
spark.sql(f"CREATE SCHEMA IF NOT EXISTS {CATALOG}.silver")

def bronze(t):
    df = spark.table(f"{CATALOG}.bronze.{t}")
    # incremental runs only look at the rows that arrived in this batch
    return df if MODE == "full" else df.filter(F.col("_batch_id") == BATCH_ID)

def save(df, name, keys):
    target = f"{CATALOG}.silver.{name}"
    if MODE == "full" or not spark.catalog.tableExists(target):
        df.write.format("delta").mode("overwrite").option("overwriteSchema", "true").saveAsTable(target)
    else:
        cond = " AND ".join(f"t.{k} = s.{k}" for k in keys)
        (DeltaTable.forName(spark, target).alias("t").merge(df.alias("s"), cond)
            .whenMatchedUpdateAll().whenNotMatchedInsertAll().execute())

# COMMAND ----------
# orders first: every child table is checked against the valid order ids
orders, q = T.clean_orders(bronze("orders"))
quarantine = q
save(orders, "orders", T.KEYS["orders"])
valid_orders = spark.table(f"{CATALOG}.silver.orders")

# COMMAND ----------
for name, fn, extra in [("customers", T.clean_customers, ()), ("products", T.clean_products, ()),
                        ("order_items", T.clean_items, (valid_orders,)), ("payments", T.clean_payments, (valid_orders,)),
                        ("reviews", T.clean_reviews, (valid_orders,))]:
    clean, q = fn(bronze(name), *extra)
    save(clean, name, T.KEYS[name])
    quarantine = quarantine.unionByName(q)

# COMMAND ----------
qt = f"{CATALOG}.silver.quarantine"
if MODE == "full" or not spark.catalog.tableExists(qt):
    quarantine.write.format("delta").mode("overwrite").option("overwriteSchema", "true").saveAsTable(qt)
else:
    (DeltaTable.forName(spark, qt).alias("t").merge(quarantine.alias("s"), "t._row_id = s._row_id AND t.reason = s.reason")
        .whenNotMatchedInsertAll().execute())

# COMMAND ----------
display(spark.table(qt).groupBy("source_table", "reason").count().orderBy("source_table", "reason"))
