# Databricks notebook source
# MAGIC %md
# MAGIC # 04 Load to Snowflake
# MAGIC Credentials come from a Databricks secret scope named `snowflake`. Create it once with the Databricks CLI:
# MAGIC `databricks secrets create-scope snowflake` then `databricks secrets put-secret snowflake sf_password`
# MAGIC (same for `sf_url`, `sf_user`). Nothing secret is stored in this file or in Git.

# COMMAND ----------
import os, sys
sys.path.append(os.path.abspath(".."))
from pyspark.sql import functions as F

dbutils.widgets.text("catalog", "retail")
dbutils.widgets.dropdown("mode", "full", ["full", "incremental"])
dbutils.widgets.text("batch_id", "full_load")
CATALOG, MODE, BATCH_ID = dbutils.widgets.get("catalog"), dbutils.widgets.get("mode"), dbutils.widgets.get("batch_id")

def secret(key):
    return dbutils.secrets.get(scope="snowflake", key=key)

sf_options = {
    "sfUrl": secret("sf_url"),                 # e.g. myorg-myaccount.snowflakecomputing.com
    "sfUser": secret("sf_user"),
    "sfPassword": secret("sf_password"),
    "sfDatabase": "RETAIL_DB",
    "sfWarehouse": "RETAIL_WH",
    "sfRole": "ENGINEER_ROLE",
    "column_mapping": "name",                  # match columns by name, not position
}

def write_sf(df, schema, table, mode):
    up = df.toDF(*[c.upper() for c in df.columns])            # Snowflake stores unquoted names in upper case
    w = up.write.format("snowflake").options(**sf_options).option("sfSchema", schema).option("dbtable", table)
    if mode == "overwrite":
        # truncate_table keeps the table (and the grants on it) instead of dropping and recreating it
        w = w.option("truncate_table", "on").option("usestagingtable", "off")
    w.mode(mode).save()

g = lambda t: spark.table(f"{CATALOG}.gold.{t}")

# COMMAND ----------
# Order lines go to RAW as an append-only landing table. A Snowflake stream + task then merge them downstream.
lines = g("fact_order_lines")
if MODE == "incremental":
    touched = spark.table(f"{CATALOG}.bronze.orders").filter(F.col("_batch_id") == BATCH_ID).select("order_id")
    lines = lines.join(touched, "order_id", "left_semi")           # only lines of new or changed orders
lines = lines.withColumn("load_batch_id", F.lit(BATCH_ID))
write_sf(lines, "RAW", "ORDER_LINES_LANDING", "append")

# COMMAND ----------
# Gold aggregates are small, so they are replaced in full on every run
for t in ["daily_sales", "top_categories", "delivery_performance", "customer_rfm", "order_status_mix", "payment_type_summary"]:
    write_sf(g(t), "ANALYTICS", t.upper(), "overwrite")

quarantine = spark.table(f"{CATALOG}.silver.quarantine").select(
    "source_table", "reason", "record_key", "raw_record", "_batch_id", "quarantined_at").withColumnRenamed("_batch_id", "batch_id")
write_sf(quarantine, "RAW", "QUARANTINE", "overwrite")

# COMMAND ----------
# Row counts to compare with Snowflake (SELECT COUNT(*) on the same tables)
for t in ["daily_sales", "top_categories", "delivery_performance", "customer_rfm", "order_status_mix", "payment_type_summary"]:
    print(t, g(t).count())
